/* Run this yourself in a private checkout, never in the public upload directory. */
const fs=require('node:fs'),path=require('node:path'),{Keypair}=require('@solana/web3.js');
const target=path.resolve(process.argv[2]||'.env.ryo-private'),treasury=Keypair.generate();
fs.writeFileSync(target,'# PRIVATE. Never upload this file or commit it.\nRYO_TREASURY_SECRET='+JSON.stringify(Array.from(treasury.secretKey))+'\n',{flag:'wx',mode:0o600});
console.log('Devnet treasury public address:',treasury.publicKey.toBase58());console.log('Private environment file created. Keep it outside public/ and import it into Netlify Functions secrets.');
