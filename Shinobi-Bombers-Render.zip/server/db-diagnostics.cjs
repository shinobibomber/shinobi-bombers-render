/* Reports configuration shape and classified errors only; never prints connection credentials. */
const fs=require('node:fs'),path=require('node:path'),{Pool}=require('pg');
const advice={
 '28P01':'PostgreSQL rejected the password. Copy a fresh Neon connection string after resetting the role password, and update the local private file as well as Netlify.',
 '28000':'PostgreSQL rejected authentication. Verify the database role and its fresh connection string.',
 '3D000':'The database name does not exist. Copy the complete connection string for the intended database from Neon Connect.',
 'ENOTFOUND':'The database hostname cannot be resolved. Check that the full URI was copied without truncation and that DNS/internet access works.',
 'ECONNREFUSED':'The database refused the connection. Check the provider endpoint and database availability.',
 'ETIMEDOUT':'The database connection timed out. Check provider status, firewall/network access and the endpoint.',
 'ECONNRESET':'The database connection was reset. Check network access, provider availability and the connection SSL settings.',
 'SELF_SIGNED_CERT_IN_CHAIN':'The TLS certificate chain is not trusted on this computer. Use the correct provider URI and a trusted CA; do not disable TLS verification globally.',
 'DEPTH_ZERO_SELF_SIGNED_CERT':'The database presented an untrusted TLS certificate. Check provider settings and the trusted CA.',
 'UNABLE_TO_VERIFY_LEAF_SIGNATURE':'The TLS certificate chain could not be verified. Check the computer/provider CA configuration.',
 'ERR_TLS_CERT_ALTNAME_INVALID':'The TLS hostname does not match the certificate. Copy the exact provider connection URI.',
 '42501':'The database role lacks permission to create or alter the Ryo tables. Use the intended database owner role.',
 '53300':'PostgreSQL has too many connections. Use the provider pooled connection URI and retry.',
};
function safeError(e){const code=/^[A-Z0-9_]{2,50}$/.test(e?.code||'')?e.code:'UNCLASSIFIED';let detail=advice[code];if(!detail&&/timeout/i.test(String(e?.message||'')))detail=advice.ETIMEDOUT;if(!detail&&/password.*must be a string/i.test(String(e?.message||'')))detail='The connection URI does not contain a usable password. Copy the full URI, not the masked display value.';return {code,advice:detail||'Check the provider connection details and availability. No raw error or private connection string is printed.'}}
function readConfig({loadFile=false}={}){const file=path.resolve('.env.ryo-private'),inherited=!!process.env.DATABASE_URL;
 if(loadFile){if(!fs.existsSync(file))throw Object.assign(Error('The .env.ryo-private file is missing from the current project root.'),{safe:true});try{process.loadEnvFile(file)}catch{throw Object.assign(Error('The private environment file could not be loaded.'),{safe:true})}}
 const value=String(process.env.DATABASE_URL||'').trim();if(!value)throw Object.assign(Error('DATABASE_URL is missing or empty. Set it in the local .env.ryo-private file; a Netlify dashboard setting is not automatically available to this terminal.'),{safe:true});
 if(/YOUR_|PLACEHOLDER|\.\.\.|\*{3,}/i.test(value))throw Object.assign(Error('DATABASE_URL still contains a placeholder, mask or truncated value. Copy the complete Neon URI privately.'),{safe:true});
 let uri;try{uri=new URL(value)}catch{throw Object.assign(Error('DATABASE_URL is not a valid URL. Use the raw postgresql:// URI, not a psql command or another DATABASE_URL= prefix.'),{safe:true})}
 if(!['postgres:','postgresql:'].includes(uri.protocol)||!uri.hostname||!uri.username||!uri.password||uri.pathname.length<2)throw Object.assign(Error('DATABASE_URL must contain protocol, role, password, hostname and database name.'),{safe:true});
 return {connectionString:value,summary:{privateFilePresent:fs.existsSync(file),shellValueOverridesFile:loadFile&&inherited,format:'PostgreSQL URI',passwordPresent:true,databasePresent:true,pooledEndpoint:uri.hostname.includes('-pooler'),sslmode:uri.searchParams.get('sslmode')||'not specified'}};
}
async function diagnose(){let pool;try{const config=readConfig({loadFile:true});console.log(JSON.stringify(config.summary,null,2));pool=new Pool({connectionString:config.connectionString,connectionTimeoutMillis:10000,max:1});const client=await pool.connect();try{await client.query('SELECT 1');console.log('Database connection and authentication: PASSED. No schema was changed.')}finally{client.release()}}catch(e){if(e.safe)console.error(e.message);else console.error(JSON.stringify(safeError(e),null,2));process.exitCode=1}finally{if(pool)await pool.end()}}
module.exports={readConfig,safeError};if(require.main===module)diagnose();
