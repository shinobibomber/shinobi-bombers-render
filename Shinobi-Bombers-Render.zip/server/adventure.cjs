/* Authoritative, active-tab auto-combat. No client damage, map, clock or reward totals are accepted. */
const {fail}=require('./store.cjs');
const HP=[100,213,1000,1625],PAY=[35625,81250,406250,812500]; // milli-Ryo
const REWARD_POOL_STEP=100000;
function rewardRatePercent(pool){return 50+10*Math.min(5,Math.floor(Math.max(0,Number(pool)||0)/REWARD_POOL_STEP))}
function advance(data,profile,now,active,ratePercent=50){
 const rate=Math.max(50,Math.min(100,Number(ratePercent)||50))/100;
 const d=data||{map:1,target:0,hp:100,kills:0,pending:0,claimed:0,last:now,active:false,energy:{}};
 const elapsed=Math.max(0,Math.min(30,(now-d.last)/1000));
 const heroes=[...profile.heroes].sort((a,b)=>b.rank-a.rank||b.level-a.level).slice(0,10);
 for(const h of heroes){const cap=50*h.baseStats.st,e=d.energy[h.tokenId]??cap;d.energy[h.tokenId]=Math.min(cap,e+elapsed*[1,2,5,8,11,14,17][profile.dojo||0]/60)}
 if(active&&d.active){
  let damage=0;
  for(const h of heroes){const energy=d.energy[h.tokenId],attacks=Math.min(energy,elapsed/Math.max(.6,1.6-h.baseStats.sp*.05)*(h.rank+1));damage+=attacks*h.baseStats.pw;d.energy[h.tokenId]-=attacks}
  while(damage>=d.hp){damage-=d.hp;d.pending+=Math.floor(PAY[d.target]*Math.max(.35,1-.1*Math.floor(d.map/100))*rate);d.kills++;if(d.kills%20===0)d.map++;d.target=d.kills%4;d.hp=HP[d.target]}
  d.hp-=damage;
 }
 d.last=now;d.active=!!active;return d;
}
async function adventure(store,wallet,{active=false,claim=false},custodyTokens){
 return store.transaction(async c=>{
  await store.locked(c,wallet);
  const profile=await store.profileLocked(c,wallet);
  const old=(await c.query('SELECT data FROM ryo_adventures WHERE scope=$1 AND wallet=$2',[store.scope,wallet])).rows[0]?.data;
  // Serialize claims across wallets. Only finalized retained purchase revenue funds rewards.
  if(claim){await c.query('INSERT INTO ryo_reward_pools(scope) VALUES($1) ON CONFLICT DO NOTHING',[store.scope]);await c.query('SELECT scope FROM ryo_reward_pools WHERE scope=$1 FOR UPDATE',[store.scope])}
  const income=(await c.query("SELECT COALESCE(SUM((quote->>'operations')::numeric),0) AS n FROM ryo_purchases WHERE scope=$1 AND status='confirmed'",[store.scope])).rows[0];
  const used=(await c.query("SELECT COALESCE(SUM((data->>'claimed')::numeric),0) AS n FROM ryo_adventures WHERE scope=$1",[store.scope])).rows[0];
  let pool=Math.max(0,Math.floor(Number(income.n)-Number(used.n)));
  const d=advance(old,profile,store.now(),active,rewardRatePercent(pool));
  let credited=0;
  if(claim){
   const liabilities=(await c.query("SELECT (SELECT COALESCE(SUM(balance),0) FROM ryo_accounts WHERE scope=$1)+(SELECT COALESCE(SUM(amount),0) FROM ryo_withdrawals WHERE scope=$1 AND status='pending')+(SELECT COALESCE(SUM(amount),0) FROM ryo_purchases WHERE scope=$1 AND status='pending') AS n",[store.scope])).rows[0];
   credited=Math.min(Math.floor(d.pending/1000),pool,Math.max(0,Math.floor(custodyTokens-Number(liabilities.n))));
   if(credited<1)fail('No funded whole Ryo is available to claim yet. Earnings stay in your Chest.',409);
   d.pending-=credited*1000;d.claimed+=credited;pool-=credited;
   await c.query('UPDATE ryo_accounts SET balance=balance+$3 WHERE scope=$1 AND wallet=$2',[store.scope,wallet,credited]);
  }
  await c.query('INSERT INTO ryo_adventures(scope,wallet,data) VALUES($1,$2,$3) ON CONFLICT(scope,wallet) DO UPDATE SET data=$3',[store.scope,wallet,JSON.stringify(d)]);
  const rate=rewardRatePercent(pool);
  return {pending:d.pending/1000,claimed:d.claimed,pool,credited,map:d.map,hp:Math.ceil(d.hp),kills:d.kills,active:d.active,rewardRatePercent:rate,rewardPoolStep:REWARD_POOL_STEP,nextRateAt:rate<100?(Math.floor(pool/REWARD_POOL_STEP)+1)*REWARD_POOL_STEP:null};
 });
}
module.exports={advance,adventure,rewardRatePercent,REWARD_POOL_STEP};
