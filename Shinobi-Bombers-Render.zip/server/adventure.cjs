/* Authoritative, visible signed-in session auto-combat. No client damage, map, clock or reward totals are accepted. */
const {fail}=require('./store.cjs');
const HP=[100,213,1000,1625],PAY=[35625,81250,406250,812500]; // milli-Ryo
const REWARD_POOL_STEP=100000;
function rewardRatePercent(pool){return 50+10*Math.min(5,Math.floor(Math.max(0,Number(pool)||0)/REWARD_POOL_STEP))}
const OFFLINE_CAP_MS=12*60*60*1000;
function advance(data,profile,now,active,ratePercent=50){
 const economy=require('./economy.cjs');economy.normalizeProfile(profile);
 const d=data||{map:1,target:0,hp:100,kills:0,pending:0,claimed:0,last:now,active:false,energy:{}};
 const rate=Math.max(50,Math.min(100,Number(ratePercent)||50))/100,last=Number(d.last)||now,gap=Math.max(0,now-last);
 const ids=new Set(profile.battleReady),roster=profile.heroes.filter(h=>ids.has(h.tokenId)).sort((a,b)=>b.rank-a.rank||b.level-a.level).slice(0,50);
 // Reserves retain their chakra but cannot attack or enter Sensei rotation.
 const readyById=new Map(roster.map(h=>[h.tokenId,h]));let heroes=(d.team||[]).map(id=>readyById.get(id)).filter(Boolean).slice(0,10);
 for(const h of roster)if(heroes.length<10&&!heroes.includes(h))heroes.push(h);
 const until=profile.sensei?Infinity:Number(profile.senseiRentalUntil||0),since=profile.sensei?Number(profile.senseiSince||0):Number(profile.senseiRentalSince||0);
 const offlineStart=Math.max(last,since),offlineEnd=Math.min(now,until,last+OFFLINE_CAP_MS);
 const online=active&&d.active&&gap<=45000;
 const start=online?last:offlineStart,end=online?now:offlineEnd;
 d.offlineSeconds=online?0:Math.max(0,(end-start)/1000);
 function step(seconds,run,sensei){
  const fighters=new Set(heroes.map(h=>h.tokenId));
  for(const h of roster){const cap=50*h.baseStats.st,e=d.energy[h.tokenId]??cap,recovery=fighters.has(h.tokenId)?1:[1,2,5,8,11,14,17][profile.dojo||0];d.energy[h.tokenId]=Math.min(cap,e+seconds*recovery/60)}
  if(sensei)for(let i=0;i<heroes.length;i++)if(d.energy[heroes[i].tokenId]<1){const replacement=roster.find(h=>!heroes.includes(h)&&d.energy[h.tokenId]>=45*h.baseStats.st);if(replacement)heroes[i]=replacement}
  if(!run)return;let damage=0;
  for(const h of heroes){const attacks=Math.min(d.energy[h.tokenId],seconds/Math.max(.6,1.6-h.baseStats.sp*.05)*(h.rank+1));damage+=attacks*h.baseStats.pw;d.energy[h.tokenId]-=attacks}
  while(damage>=d.hp){damage-=d.hp;d.pending+=Math.floor(PAY[d.target]*Math.max(.35,1-.1*Math.floor(d.map/100))*rate);d.kills++;if(d.kills%20===0)d.map++;d.target=d.kills%4;d.hp=HP[d.target]}
  d.hp-=damage;
 }
 if(end>start){if(start>last)step(Math.min(OFFLINE_CAP_MS,start-last)/1000,false,false);for(let at=start;at<end;at+=15000)step(Math.min(15000,end-at)/1000,true,economy.senseiActive(profile,at));if(now>end)step(Math.min(OFFLINE_CAP_MS,now-end)/1000,false,false)}else step(Math.min(OFFLINE_CAP_MS,gap)/1000,false,false);
 d.team=heroes.map(h=>h.tokenId);d.last=now;d.active=!!active;return d;
}
async function settleLocked(store,c,wallet,profile,active=false){
 const row=(await c.query('SELECT data FROM ryo_adventures WHERE scope=$1 AND wallet=$2',[store.scope,wallet])).rows[0];
 const income=(await c.query("SELECT COALESCE(SUM((quote->>'operations')::numeric),0) AS n FROM ryo_purchases WHERE scope=$1 AND status='confirmed'",[store.scope])).rows[0];
 const used=(await c.query("SELECT COALESCE(SUM((data->>'claimed')::numeric),0) AS n FROM ryo_adventures WHERE scope=$1",[store.scope])).rows[0];
 const d=advance(row?.data,profile,store.now(),active,rewardRatePercent(Math.max(0,Number(income.n)-Number(used.n))));
 await c.query('INSERT INTO ryo_adventures(scope,wallet,data) VALUES($1,$2,$3) ON CONFLICT(scope,wallet) DO UPDATE SET data=$3',[store.scope,wallet,JSON.stringify(d)]);return d;
}
async function adventure(store,wallet,{active=false,claim=false},custodyTokens){
 return store.transaction(async c=>{
  await store.locked(c,wallet);
  const profile=await store.profileLocked(c,wallet);
  const old=(await c.query('SELECT data FROM ryo_adventures WHERE scope=$1 AND wallet=$2',[store.scope,wallet])).rows[0]?.data;
  // Serialize claims across wallets. Only finalized retained purchase revenue funds rewards.
  if(claim){await c.query('INSERT INTO ryo_reward_pools(scope) VALUES($1) ON CONFLICT DO NOTHING',[store.scope]);await c.query('SELECT scope FROM ryo_reward_pools WHERE scope=$1 FOR UPDATE',[store.scope])}
  const income=(await c.query("SELECT COALESCE(SUM((quote->>'operations')::numeric),0) AS n FROM ryo_purchases WHERE scope=$1 AND status='confirmed'",[store.scope])).rows[0];
  const used=(await c.query("SELECT COALESCE(SUM((data->>'claimed')::numeric),0) AS n FROM ryo_adventures WHERE scope=$1",[store.scope])).rows[0];
  let pool=Math.max(0,Math.floor(Number(income.n)-Number(used.n)));
  const d=advance(old,profile,store.now(),active,rewardRatePercent(pool));
  let credited=0;
  if(claim){
   const liabilities=(await c.query("SELECT (SELECT COALESCE(SUM(balance),0) FROM ryo_accounts WHERE scope=$1)+(SELECT COALESCE(SUM(amount),0) FROM ryo_withdrawals WHERE scope=$1 AND status='pending')+(SELECT COALESCE(SUM(amount),0) FROM ryo_purchases WHERE scope=$1 AND status='pending') AS n",[store.scope])).rows[0];
   credited=Math.min(Math.floor(d.pending/1000),pool,Math.max(0,Math.floor(custodyTokens-Number(liabilities.n))));
   if(credited<1)fail('No funded whole Ryo is available to claim yet. Earnings stay in your Chest.',409);
   d.pending-=credited*1000;d.claimed+=credited;pool-=credited;
   await c.query('UPDATE ryo_accounts SET balance=balance+$3 WHERE scope=$1 AND wallet=$2',[store.scope,wallet,credited]);
  }
  await c.query('INSERT INTO ryo_adventures(scope,wallet,data) VALUES($1,$2,$3) ON CONFLICT(scope,wallet) DO UPDATE SET data=$3',[store.scope,wallet,JSON.stringify(d)]);
  const rate=rewardRatePercent(pool);
  return {pending:d.pending/1000,claimed:d.claimed,pool,credited,map:d.map,hp:Math.ceil(d.hp),kills:d.kills,active:d.active,offlineSeconds:d.offlineSeconds||0,offlineCapHours:12,senseiActive:require('./economy.cjs').senseiActive(profile,store.now()),rewardRatePercent:rate,rewardPoolStep:REWARD_POOL_STEP,nextRateAt:rate<100?(Math.floor(pool/REWARD_POOL_STEP)+1)*REWARD_POOL_STEP:null};
 });
}
module.exports={settleLocked,OFFLINE_CAP_MS,advance,adventure,rewardRatePercent,REWARD_POOL_STEP};
