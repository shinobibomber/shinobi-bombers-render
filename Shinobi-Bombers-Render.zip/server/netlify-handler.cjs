const {Pool}=require('pg'),{Keypair,Connection}=require('@solana/web3.js'),{Store}=require('./store.cjs'),{createService}=require('./service.cjs');
let service;
function getService(){if(service)return service;const {DATABASE_URL,RYO_TREASURY_SECRET,RYO_TOKEN_MINT,RYO_SITE_ORIGIN,RYO_STUDIO_WALLET,RYO_REVENUE_WALLET}=process.env;
 const required={DATABASE_URL,RYO_TREASURY_SECRET,RYO_TOKEN_MINT,RYO_SITE_ORIGIN,RYO_STUDIO_WALLET,RYO_REVENUE_WALLET};
 const missing=Object.keys(required).filter(name=>!String(required[name]||'').trim());
 if(missing.length)throw Object.assign(Error('Missing server settings: '+missing.join(', ')+'. Add these in your hosting service private environment variables, then redeploy.'),{status:503,missing});
 const origin=new URL(RYO_SITE_ORIGIN).origin;if(!origin.startsWith('https://')&& !/^http:\/\/(localhost|127\.0\.0\.1)(:|$)/.test(origin))throw Error('Invalid site origin.');
 const treasury=Keypair.fromSecretKey(Uint8Array.from(JSON.parse(RYO_TREASURY_SECRET))),connection=new Connection(process.env.SOLANA_DEVNET_RPC_URL||'https://api.devnet.solana.com','finalized');
 const scope='solana-devnet:'+RYO_TOKEN_MINT+':'+treasury.publicKey.toBase58(),pool=new Pool({connectionString:DATABASE_URL,max:3,connectionTimeoutMillis:8000,idleTimeoutMillis:10000,statement_timeout:15000});
 service=createService({store:new Store(pool,scope),connection,treasury,mint:RYO_TOKEN_MINT,origin,studioAddress:RYO_STUDIO_WALLET,revenueAddress:RYO_REVENUE_WALLET});return service;
}
exports.handler=async event=>{
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Origin'};
 try{
  const requestHeaders=Object.fromEntries(Object.entries(event.headers||{}).map(([k,v])=>[k.toLowerCase(),v]));
  if(event.httpMethod!=='POST')return {statusCode:405,headers,body:JSON.stringify({error:'POST required.'})};
  const configuredOrigin=String(process.env.RYO_SITE_ORIGIN||'').trim(),expected=configuredOrigin?new URL(configuredOrigin).origin:null;
  if(expected&&requestHeaders.origin!==expected)throw Object.assign(Error('Request origin is not allowed.'),{status:403});
  if(!String(requestHeaders['content-type']||'').startsWith('application/json'))throw Object.assign(Error('JSON required.'),{status:415});
  if(event.isBase64Encoded||String(event.body||'').length>8192)throw Object.assign(Error('Request is too large.'),{status:413});
  let input;try{input=JSON.parse(event.body||'{}')}catch{throw Object.assign(Error('Invalid JSON.'),{status:400})}
  const token=String(requestHeaders.authorization||'').replace(/^Bearer /,''),result=await getService().handle(input.action,input,token);
  return {statusCode:200,headers,body:JSON.stringify(result)};
 }catch(e){const status=e.status||503;return {statusCode:status,headers,body:JSON.stringify({error:e.status?e.message:'Ryo service is temporarily unavailable. Contact the organizer.',...(Array.isArray(e.missing)?{missingSettings:e.missing}:{})})}}
};

