const crypto=require('node:crypto'),{fail}=require('./store.cjs');
const VERSION=2,DAY=86400000,MIN_WITHDRAW=100000,MAX_TRANSFER=1000000;
const dojoPrices=[0,1800000,6000000,13500000,24000000,37500000,54000000];
const fee=amount=>Math.ceil(amount/50); // 2%, rounded up to a whole Ryo.
function hero(rank=0){const [lo,hi]=[[1,3],[3,6],[6,9],[9,12],[12,15]][rank],roll=()=>crypto.randomInt(lo,hi+1);return {tokenId:crypto.randomUUID(),rank,level:1,name:['Nao','Ren','Aki','Kai','Yuki','Sora'][crypto.randomInt(6)]+' of '+['Ember Ridge','Crimson Dusk','Hidden Leaf','Silent Rain'][crypto.randomInt(4)],baseStats:{pw:roll(),sp:roll(),st:roll()}}}
function initialProfile(){return {version:1,dojo:0,sensei:false,heroes:[hero(),hero()]}}
function normalizeProfile(profile){if(!Array.isArray(profile.battleReady))profile.battleReady=[...profile.heroes].sort((a,b)=>b.rank-a.rank||b.level-a.level).slice(0,50).map(h=>h.tokenId);const owned=new Set(profile.heroes.map(h=>h.tokenId));profile.battleReady=[...new Set(profile.battleReady)].filter(id=>owned.has(id)).slice(0,50);return profile}
function senseiActive(profile,now=Date.now()){return profile.sensei===true||Number(profile.senseiRentalUntil||0)>now}
function quote(profile,product,params={}){
 normalizeProfile(profile);
 let base,title,target;
 if(product==='summon'){if(![1,5,10,15].includes(params.quantity))fail('Choose 1, 5, 10 or 15 summons.');base=25000*params.quantity;title='Summon '+params.quantity+' hero'+(params.quantity===1?'':'es')}
 else if(product==='training'){target=profile.heroes.find(h=>h.tokenId===params.heroId);if(!target||target.level>=10)fail('Choose an owned token-recruited hero below level 10.');base=Math.round(5000*Math.pow(target.level,1.65)*(1+target.rank*.45));title='Train '+target.name+' to level '+(target.level+1)}
 else if(product==='dojo'){if(profile.dojo>=6)fail('Dojo is already max level.');base=dojoPrices[profile.dojo+1];title='Dojo tier '+(profile.dojo+1)}
 else if(product==='sensei'){if(profile.sensei)fail('Sensei is already hired.');base=1512500;title='Hire Sensei'}
 else if(product==='sensei-rental'){if(profile.sensei)fail('Permanent Sensei is already owned.');base=250000;title='Rent Sensei for 7 days'}
 else if(product==='fusion'){
  if(!Array.isArray(params.heroIds)||params.heroIds.length<3||params.heroIds.length>75||params.heroIds.length%3||new Set(params.heroIds).size!==params.heroIds.length)fail('Select complete groups of three unique heroes.');
  const list=params.heroIds.map(id=>profile.heroes.find(h=>h.tokenId===id));if(list.some(h=>!h||h.rank>=4)||list.some(h=>h.rank!==list[0].rank))fail('Fusion needs owned heroes of the same rank below Legend.');
  if(params.heroIds.some(id=>profile.battleReady.includes(id)))fail('Only Reserve heroes can be fused. Move selected heroes to Reserve first.');
  if(profile.heroes.length-list.length+list.length/3<2)fail('Keep at least two heroes in the server token collection after fusion.');
  base=25000*(list.length/3);title='Fuse '+list.length+' heroes into '+list.length/3;
 }else fail('Unknown token purchase.',404);
 const studioFee=fee(base);return {economyVersion:VERSION,product,params,title,base,studioFee,total:base+studioFee,treasury:base/10,burn:base/10,operations:base*.8};
}
function fulfill(profile,q,now=Date.now()){const next=normalizeProfile(structuredClone(profile)),outputs=[];
 if(q.product==='summon'){for(let i=0;i<q.params.quantity;i++){const roll=crypto.randomInt(10000),rank=roll<6000?0:roll<8500?1:roll<9500?2:roll<9900?3:4;outputs.push(hero(rank))}next.heroes.push(...outputs)}
 if(q.product==='training')next.heroes.find(h=>h.tokenId===q.params.heroId).level++;
 if(q.product==='dojo')next.dojo++;if(q.product==='sensei'){next.sensei=true;next.senseiSince=now}
 if(q.product==='sensei-rental'){next.senseiRentalSince=Number(next.senseiRentalUntil||0)>now?next.senseiRentalSince:now;next.senseiRentalUntil=Math.max(now,Number(next.senseiRentalUntil||0))+7*DAY}
 if(q.product==='fusion'){const consumed=new Set(q.params.heroIds),rank=next.heroes.find(h=>consumed.has(h.tokenId)).rank;for(let i=0;i<consumed.size/3;i++)outputs.push(hero(rank+1));next.heroes=next.heroes.filter(h=>!consumed.has(h.tokenId));next.heroes.push(...outputs)}
 normalizeProfile(next);return {profile:next,result:{product:q.product,title:q.title,outputs,consumed:q.product==='fusion'?q.params.heroIds:[]}};
}
module.exports={normalizeProfile,senseiActive,VERSION,DAY,MIN_WITHDRAW,MAX_TRANSFER,fee,quote,fulfill,initialProfile};
