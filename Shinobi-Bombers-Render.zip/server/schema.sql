CREATE TABLE IF NOT EXISTS ryo_accounts (
 scope TEXT NOT NULL, wallet TEXT NOT NULL, balance BIGINT NOT NULL DEFAULT 0 CHECK(balance >= 0),
 PRIMARY KEY(scope,wallet)
);
CREATE TABLE IF NOT EXISTS ryo_challenges (
 scope TEXT NOT NULL,wallet TEXT NOT NULL,nonce TEXT NOT NULL,message TEXT NOT NULL,expires BIGINT NOT NULL,created BIGINT NOT NULL,
 PRIMARY KEY(scope,wallet)
);
CREATE TABLE IF NOT EXISTS ryo_sessions (
 scope TEXT NOT NULL, token_hash TEXT NOT NULL,wallet TEXT NOT NULL,expires BIGINT NOT NULL,
 PRIMARY KEY(scope,token_hash)
);
CREATE TABLE IF NOT EXISTS ryo_deposits (
 scope TEXT NOT NULL,signature TEXT NOT NULL,wallet TEXT NOT NULL,amount BIGINT NOT NULL CHECK(amount>0),request_id TEXT NOT NULL,created BIGINT NOT NULL,
 PRIMARY KEY(scope,signature), UNIQUE(scope,wallet,request_id)
);
CREATE TABLE IF NOT EXISTS ryo_spends (
 scope TEXT NOT NULL,wallet TEXT NOT NULL,request_id TEXT NOT NULL,amount BIGINT NOT NULL CHECK(amount>0),acknowledged BOOLEAN NOT NULL DEFAULT FALSE,created BIGINT NOT NULL,
 PRIMARY KEY(scope,wallet,request_id)
);
CREATE TABLE IF NOT EXISTS ryo_withdrawals (
 scope TEXT NOT NULL,wallet TEXT NOT NULL,request_id TEXT NOT NULL,amount BIGINT NOT NULL CHECK(amount>0),
 signature TEXT NOT NULL,wire TEXT NOT NULL,last_height BIGINT NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','refunded')),
 created BIGINT NOT NULL, PRIMARY KEY(scope,wallet,request_id),UNIQUE(scope,signature)
);
-- Additive, idempotent upgrades. Existing deposits and balances are preserved.
ALTER TABLE ryo_deposits ADD COLUMN IF NOT EXISTS gross BIGINT;
ALTER TABLE ryo_deposits ADD COLUMN IF NOT EXISTS studio_fee BIGINT NOT NULL DEFAULT 0;
ALTER TABLE ryo_withdrawals ADD COLUMN IF NOT EXISTS studio_fee BIGINT NOT NULL DEFAULT 0;
ALTER TABLE ryo_withdrawals ADD COLUMN IF NOT EXISTS net BIGINT;
ALTER TABLE ryo_withdrawals ADD COLUMN IF NOT EXISTS settled_at BIGINT;
CREATE TABLE IF NOT EXISTS ryo_profiles (
 scope TEXT NOT NULL,wallet TEXT NOT NULL,data JSONB NOT NULL,PRIMARY KEY(scope,wallet)
);
CREATE TABLE IF NOT EXISTS ryo_purchases (
 scope TEXT NOT NULL,wallet TEXT NOT NULL,request_id TEXT NOT NULL,
 product TEXT NOT NULL,params JSONB NOT NULL,quote JSONB NOT NULL,result JSONB NOT NULL,profile_after JSONB NOT NULL,
 amount BIGINT NOT NULL CHECK(amount>0),signature TEXT NOT NULL,wire TEXT NOT NULL,last_height BIGINT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','refunded')),
 acknowledged BOOLEAN NOT NULL DEFAULT FALSE,created BIGINT NOT NULL,settled_at BIGINT,
 PRIMARY KEY(scope,wallet,request_id),UNIQUE(scope,signature)
);

CREATE TABLE IF NOT EXISTS ryo_adventures (scope TEXT NOT NULL,wallet TEXT NOT NULL,data JSONB NOT NULL,PRIMARY KEY(scope,wallet));
CREATE TABLE IF NOT EXISTS ryo_reward_pools (scope TEXT PRIMARY KEY);

CREATE TABLE IF NOT EXISTS ryo_presence (scope TEXT NOT NULL,session_hash TEXT NOT NULL,wallet TEXT NOT NULL,last_seen BIGINT NOT NULL,PRIMARY KEY(scope,session_hash));
CREATE INDEX IF NOT EXISTS ryo_presence_recent ON ryo_presence(scope,last_seen);
