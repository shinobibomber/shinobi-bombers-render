/* Same-origin Node host for Render. Only public/ is served; server secrets stay private. */
const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
function createServer({publicRoot=path.resolve(__dirname,'../public'),handler=require('./netlify-handler.cjs').handler}={}){
 if(!process.env.RYO_SITE_ORIGIN&&process.env.RENDER_EXTERNAL_URL)process.env.RYO_SITE_ORIGIN=new URL(process.env.RENDER_EXTERNAL_URL).origin;
 const root=fs.realpathSync(publicRoot),types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon','.md':'text/plain','.txt':'text/plain','.sol':'text/plain','.pdf':'application/pdf'};
 function send(res,status,data,type='application/json',method='GET'){
  res.writeHead(status,{'Content-Type':type+'; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'});res.end(method==='HEAD'?undefined:typeof data==='string'?data:JSON.stringify(data));
 }
 const server=http.createServer(async(req,res)=>{
  try{
   let name;try{name=decodeURIComponent(new URL(req.url,'http://localhost').pathname)}catch{return send(res,400,{error:'Invalid path.'})}
   if(name==='/healthz')return send(res,200,{status:'ok'},undefined,req.method);
   if(name==='/.netlify/functions/ryo'||name==='/api/ryo'){
    let size=0,chunks=[],oversized=false;
    req.on('data',chunk=>{size+=chunk.length;if(size>8192){chunks=[];if(!oversized){oversized=true;send(res,413,{error:'Request is too large.'})}}else if(!oversized)chunks.push(chunk)});
    req.on('end',async()=>{if(oversized)return;try{const result=await handler({httpMethod:req.method,headers:req.headers,body:Buffer.concat(chunks).toString('utf8')});if(res.destroyed)return;res.writeHead(result.statusCode,result.headers);res.end(result.body)}catch{if(!res.headersSent)send(res,503,{error:'Ryo service is temporarily unavailable.'})}});
    req.on('error',()=>{if(!res.headersSent)send(res,400,{error:'Invalid request.'})});return;
   }
   if(!['GET','HEAD'].includes(req.method))return send(res,405,{error:'GET or HEAD required.'});
   if(name==='/beta-config.json'){
    if(!process.env.RYO_TOKEN_MINT||!process.env.RYO_STUDIO_WALLET)return send(res,503,{error:'Public token configuration is not ready.'});
    return send(res,200,{network:'solana-devnet',rpcUrl:'https://api.devnet.solana.com/',tokenAddress:process.env.RYO_TOKEN_MINT,studioAddress:process.env.RYO_STUDIO_WALLET},undefined,req.method);
   }
   if(name.split('/').some(part=>part.startsWith('.'))||name.includes('\\')||name.includes('\0'))return send(res,404,{error:'Not found.'});
   const candidate=path.resolve(root,'.'+(name==='/'?'/index.html':name));
   if(!candidate.startsWith(root+path.sep))return send(res,404,{error:'Not found.'});
   let target;try{target=await fs.promises.realpath(candidate)}catch{return send(res,404,{error:'Not found.'})}
   if(!target.startsWith(root+path.sep)||(await fs.promises.stat(target)).isDirectory())return send(res,404,{error:'Not found.'});
   const type=types[path.extname(target).toLowerCase()];if(!type)return send(res,404,{error:'Not found.'});
   res.writeHead(200,{'Content-Type':type+(/^(text\/|application\/json)/.test(type)?'; charset=utf-8':''),'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'});
   if(req.method==='HEAD')return res.end();const stream=fs.createReadStream(target);stream.on('error',()=>res.destroy());stream.pipe(res);
  }catch{if(!res.headersSent)send(res,503,{error:'Service is temporarily unavailable.'})}
 });
 server.requestTimeout=30000;server.headersTimeout=15000;return server;
}
if(require.main===module){const server=createServer();server.listen(Number(process.env.PORT)||10000,'0.0.0.0',()=>console.log('Shinobi Render server is listening.'));process.on('SIGTERM',()=>{server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),10000).unref()})}
module.exports={createServer};
