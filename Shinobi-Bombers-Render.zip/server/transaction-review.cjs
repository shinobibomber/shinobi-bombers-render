/* Shared wallet compatibility policy. Token instructions and account privileges remain exact. */
const {Buffer}=require('buffer'),bs58=require('bs58'),{Message,Transaction,ComputeBudgetProgram}=require('@solana/web3.js');
const COMPUTE=ComputeBudgetProgram.programId.toBase58(),MAX_UNITS=1400000,MAX_PRIORITY_LAMPORTS=100000n;
function budgetInfo(instructions,{enforcePriorityCap=true}={}){
 let units=null,price=null,budgetCount=0,coreCount=0;
 for(const ix of instructions){if(ix.programId.toString()!==COMPUTE){coreCount++;continue}budgetCount++;
  const accounts=ix.accounts||ix.keys||[],data=typeof ix.data==='string'?Buffer.from(bs58.decode(ix.data)):Buffer.from(ix.data||[]);
  if(accounts.length)throw Error('Network compute-budget instructions cannot reference accounts.');
  if(data[0]===2&&data.length===5&&units===null){units=data.readUInt32LE(1);if(units<1||units>MAX_UNITS)throw Error('Invalid network compute-unit limit.');}
  else if(data[0]===3&&data.length===9&&price===null)price=data.readBigUInt64LE(1);
  else throw Error('Unsupported or duplicate network compute-budget instruction.');
 }
 const effectiveUnits=BigInt(units===null?Math.min(MAX_UNITS,coreCount*200000):units),priority=(effectiveUnits*(price||0n)+999999n)/1000000n;
 if(enforcePriorityCap&&priority>MAX_PRIORITY_LAMPORTS)throw Error('Wallet priority fee exceeds 0.0001 Devnet SOL. Lower the wallet network fee and retry.');
 return {budgetCount,priorityLamports:priority};
}
function stripComputeBudgetInstructions(instructions,options){budgetInfo(instructions,options);return instructions.filter(ix=>ix.programId.toString()!==COMPUTE)}
function canonical(message){return message.instructions.map(ix=>({programId:message.accountKeys[ix.programIdIndex].toBase58(),accounts:ix.accounts.map(i=>message.accountKeys[i].toBase58()),data:ix.data}))}
function validateReviewedTransaction(reviewedBytes,signedWire){
 const expected=Message.from(Buffer.from(reviewedBytes)),wire=Buffer.from(signedWire);if(wire.length>1232)throw Error('Wallet transaction exceeds the supported packet size.');
 const transaction=Transaction.from(wire);if(!transaction.verifySignatures())throw Error('Wallet transaction signature verification failed.');const actual=Message.from(transaction.serializeMessage());
 const different=reason=>{throw Error('The signed transaction differs from the reviewed request: '+reason+'. This app did not submit it.');};
 if(expected.recentBlockhash!==actual.recentBlockhash)different('blockhash changed');
 if(expected.accountKeys[0].toBase58()!==actual.accountKeys[0].toBase58())different('fee payer changed');
 const expectedInstructions=canonical(expected),actualInstructions=canonical(actual),limits=budgetInfo(actualInstructions);
 const core=items=>items.filter(ix=>ix.programId!==COMPUTE);
 if(JSON.stringify(core(expectedInstructions))!==JSON.stringify(core(actualInstructions)))different('token instructions, recipients, amounts or memo changed');
 const existingBudget=expectedInstructions.filter(ix=>ix.programId===COMPUTE);if(existingBudget.length&&JSON.stringify(existingBudget)!==JSON.stringify(actualInstructions.filter(ix=>ix.programId===COMPUTE)))different('an existing app network-fee policy changed');
 const roles=message=>new Map(message.accountKeys.map((pubkey,index)=>[pubkey.toBase58(),{signer:message.isAccountSigner(index),writable:message.isAccountWritable(index)}]));
 const expectedRoles=roles(expected),actualRoles=roles(actual);
 for(const [account,role]of expectedRoles){const other=actualRoles.get(account);if(!other||role.signer!==other.signer||role.writable!==other.writable)different('account signer or writable privileges changed');}
 for(const [account,role]of actualRoles)if(!expectedRoles.has(account)&&(account!==COMPUTE||!limits.budgetCount||role.signer||role.writable))different('unexpected account added');
 return {transaction,priorityLamports:limits.priorityLamports};
}
module.exports={validateReviewedTransaction,stripComputeBudgetInstructions,MAX_PRIORITY_LAMPORTS};
