const crypto=require('node:crypto'),web3=require('@solana/web3.js'),spl=require('@solana/spl-token'),bs58=require('bs58');
const {fail}=require('./store.cjs'),economy=require('./economy.cjs');
const {stripComputeBudgetInstructions}=require('./transaction-review.cjs');
const GENESIS='EtWTRABZaYq6iMfeYKouRu166VU2xqa1wcaWoxPkrZBG',UNIT=1000000n,NETWORK='solana-devnet',MEMO=new web3.PublicKey('MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr');
const key=x=>new web3.PublicKey(x),address=x=>{try{if(typeof x!=='string'||key(x).toBase58()!==x)fail('Invalid Solana address.');return x}catch{fail('Invalid Solana address.')}};
function amount(value){if(!Number.isSafeInteger(value)||value<1000||value>1000000)fail('Choose a whole amount between 1,000 and 1,000,000 Ryo.');return value}
function requestId(value){if(typeof value!=='string'||!/^[-a-zA-Z0-9_]{16,80}$/.test(value))fail('Invalid request ID.');return value}
function signature(value){if(typeof value!=='string'||!/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(value))fail('Invalid Solana signature.');return value}
function verifySignature(wallet,message,sig){try{const bytes=Buffer.from(sig,'base64');if(bytes.length!==64)return false;const publicKey=crypto.createPublicKey({key:Buffer.concat([Buffer.from('302a300506032b6570032100','hex'),key(wallet).toBuffer()]),format:'der',type:'spki'});return crypto.verify(null,Buffer.from(message),publicKey,bytes)}catch{return false}}
function verifyDeposit(receipt,{wallet,mint,treasury,studio,signature:hash,amount:ryo,requestId:id}){
 if(!receipt?.meta||receipt.meta.err||receipt.transaction?.signatures?.[0]!==hash)fail('Deposit is failed or does not match the signature.');
 const message=receipt.transaction.message,keys=message.accountKeys,feePayer=keys?.[0];if(!feePayer?.signer||feePayer.pubkey.toString()!==wallet)fail('Deposit must be signed by your connected wallet.');
 const source=spl.getAssociatedTokenAddressSync(key(mint),key(wallet)).toBase58(),vault=spl.getAssociatedTokenAddressSync(key(mint),key(treasury)).toBase58(),feeAccount=spl.getAssociatedTokenAddressSync(key(mint),key(studio)).toBase58();let instructions;try{instructions=stripComputeBudgetInstructions(message.instructions,{enforcePriorityCap:false})}catch{fail('Invalid wallet network-fee instructions.');}
 if(!Array.isArray(instructions)||instructions.length<3||instructions.length>5)fail('Unexpected deposit instructions.');
 const transfers=instructions.filter(i=>i.programId.toString()===spl.TOKEN_PROGRAM_ID.toBase58()),memos=instructions.filter(i=>i.programId.toString()===MEMO.toBase58());
 if(transfers.length!==2||memos.length!==1||memos[0].parsed!=='shinobi-deposit-v2:'+id)fail('Missing deposit/fee transfers or memo.');
 if(instructions.some(i=>![spl.TOKEN_PROGRAM_ID.toBase58(),MEMO.toBase58(),spl.ASSOCIATED_TOKEN_PROGRAM_ID.toBase58()].includes(i.programId.toString())))fail('Unexpected program in deposit.');
 const fee=economy.fee(ryo),net=ryo-fee;
 for(const [destination,n]of [[vault,net],[feeAccount,fee]]){const matches=transfers.filter(t=>{const i=t.parsed?.info;return t.parsed?.type==='transferChecked'&&i?.authority===wallet&&i.source===source&&i.destination===destination&&i.mint===mint&&i.tokenAmount?.amount===(BigInt(n)*UNIT).toString()&&i.tokenAmount?.decimals===6});if(matches.length!==1)fail('Deposit or studio-fee recipient/mint/amount does not match.');}
 function delta(account,owner){const index=keys.findIndex(k=>k.pubkey.toString()===account);if(index<0)fail('Missing deposit account.');const find=list=>list?.find(b=>b.accountIndex===index&&b.mint===mint&&b.owner===owner);return BigInt(find(receipt.meta.postTokenBalances)?.uiTokenAmount.amount||0)-BigInt(find(receipt.meta.preTokenBalances)?.uiTokenAmount.amount||0)}
 if(delta(source,wallet)!==-BigInt(ryo)*UNIT||delta(vault,treasury)!==BigInt(net)*UNIT||delta(feeAccount,studio)!==BigInt(fee)*UNIT)fail('Finalized token balances do not confirm deposit and fee.');return {gross:ryo,studioFee:fee,net};
}
function publicOperation(row,kind){return {request_id:row.request_id,amount:Number(row.amount),signature:row.signature,status:row.status,...(kind==='purchase'?{quote:row.quote,result:row.status==='confirmed'?row.result:null}:{studio_fee:Number(row.studio_fee||0),net:Number(row.net||row.amount)})}}
function createService({store,connection,treasury,mint,origin,studioAddress,revenueAddress}){
 address(mint);address(studioAddress);address(revenueAddress);const treasuryAddress=treasury.publicKey.toBase58(),treasuryAta=spl.getAssociatedTokenAddressSync(key(mint),treasury.publicKey);
 if([studioAddress,revenueAddress].includes(treasuryAddress))fail('Studio and revenue destinations must be separate from the custody treasury.',503);
 async function checkNetwork(){if(await connection.getGenesisHash()!==GENESIS)fail('Treasury RPC is not Solana Devnet.',503)}
 async function checkMint(){await checkNetwork();const value=await spl.getMint(connection,key(mint),'finalized');if(value.decimals!==6||value.mintAuthority||value.freezeAuthority||value.supply>1000000000n*UNIT)fail('Server token mint does not match the fixed-supply beta token.',503)}
 async function progress(row,kind='withdrawal'){
  if(row.status!=='pending')return publicOperation(row,kind);await checkNetwork();const settle=status=>kind==='purchase'?store.settlePurchase(row.wallet,row.request_id,status):store.settle(row.wallet,row.request_id,status);
  const status=(await connection.getSignatureStatuses([row.signature],{searchTransactionHistory:true})).value[0];
  if(status?.confirmationStatus==='finalized')return publicOperation(await settle(status.err?'refunded':'confirmed'),kind);
  if(status)return publicOperation(row,kind);
  const height=await connection.getBlockHeight('finalized');
  if(height>Number(row.last_height)){const again=(await connection.getSignatureStatuses([row.signature],{searchTransactionHistory:true})).value[0];if(again?.confirmationStatus==='finalized')return publicOperation(await settle(again.err?'refunded':'confirmed'),kind);if(!again)return publicOperation(await settle('refunded'),kind);return publicOperation(row,kind)}
  try{await connection.sendRawTransaction(Buffer.from(row.wire,'base64'),{skipPreflight:false,preflightCommitment:'confirmed',maxRetries:2})}catch{/* Ambiguous broadcasts stay reserved until finalized or proven expired. */}
  return publicOperation(row,kind);
 }
 async function state(wallet){await checkNetwork();for(const row of await store.pending(wallet))await progress(row);for(const row of await store.pendingPurchases(wallet))await progress(row,'purchase');return store.state(wallet)}
 async function signedTransaction(instructions){const block=await connection.getLatestBlockhash('finalized'),tx=new web3.Transaction({feePayer:treasury.publicKey,blockhash:block.blockhash,lastValidBlockHeight:block.lastValidBlockHeight}).add(...instructions);tx.sign(treasury);return {signature:bs58.encode(tx.signature),wire:tx.serialize().toString('base64'),lastHeight:block.lastValidBlockHeight}}
 function transferTo(destination,raw){const owner=key(destination),ata=spl.getAssociatedTokenAddressSync(key(mint),owner);return [spl.createAssociatedTokenAccountIdempotentInstruction(treasury.publicKey,ata,owner,key(mint)),spl.createTransferCheckedInstruction(treasuryAta,key(mint),ata,treasury.publicKey,raw,6)]}
 const memo=text=>new web3.TransactionInstruction({programId:MEMO,keys:[],data:Buffer.from(text)});
 async function handle(action,body,token){
  if(action==='config'){await checkMint();return {economyVersion:2,network:NETWORK,mint,treasuryAddress,studioAddress,revenueAddress,decimals:6,rate:1,minAmount:1000,maxAmount:1000000,withdrawalMinimum:100000,withdrawalCooldownMs:86400000,studioFeeBps:200,purchaseTreasuryBps:1000,purchaseBurnBps:1000,tokenPurchases:true}}
  if(action==='challenge'){const wallet=address(body.wallet);if([treasuryAddress,studioAddress,revenueAddress].includes(wallet))fail('Use a player wallet separate from custody, studio and revenue wallets.');const nonce=crypto.randomBytes(24).toString('hex'),message=[new URL(origin).host+' requests a Shinobi Ryo beta login.',`Wallet: ${wallet}`,`Origin: ${origin}`,`Network: ${NETWORK}`,`Mint: ${mint}`,`Nonce: ${nonce}`,`Expires: ${new Date(Date.now()+120000).toISOString()}`,'This signs you in. It does not transfer tokens.'].join('\n');return store.challenge(wallet,message,nonce)}
  if(action==='login'){const wallet=address(body.wallet);if(typeof body.signature!=='string'||body.signature.length>100)fail('Invalid wallet login signature.');return store.login(wallet,body.nonce,message=>verifySignature(wallet,message,body.signature))}
  const wallet=await store.authenticate(token);if([treasuryAddress,studioAddress,revenueAddress].includes(wallet))fail('Custody/studio/revenue wallets cannot act as players.');if(action==='state')return state(wallet);
  if(action==='adventure'||action==='claim-adventure'){
   await checkNetwork();const claim=action==='claim-adventure';let available=0;if(claim){await checkMint();available=Number((await connection.getTokenAccountBalance(treasuryAta,'finalized')).value.amount)/Number(UNIT)}
   const chest=await require('./adventure.cjs').adventure(store,wallet,{active:body.active===true,claim},available);return {chest,...(claim?await state(wallet):{})};
  }
  if(action==='deposit'){
   await checkMint();const gross=amount(body.amount),hash=signature(body.signature),id=requestId(body.requestId),receipt=await connection.getParsedTransaction(hash,{commitment:'finalized',maxSupportedTransactionVersion:0});if(!receipt)fail('Deposit has not finalized yet. Refresh to recover it.',409);
   const split=verifyDeposit(receipt,{wallet,mint,treasury:treasuryAddress,studio:studioAddress,signature:hash,amount:gross,requestId:id});const result=await store.deposit(wallet,{signature:hash,requestId:id,amount:split.net,gross,studioFee:split.studioFee});return {...result,...await store.state(wallet)};
  }
  if(action==='spend')fail('Prepaid game packs are retired. Use token checkout for each purchase.',410);
  if(action==='ack-spend')return store.acknowledge(wallet,requestId(body.requestId));
  if(action==='quote')return economy.quote(await store.profile(wallet),body.product,body.params||{});
  if(action==='purchase'){
   await checkMint();const id=requestId(body.requestId);const row=await store.purchase(wallet,id,body.product,body.params||{},body.expectedTotal,async q=>{
    const available=await connection.getTokenAccountBalance(treasuryAta,'finalized');if(BigInt(available.value.amount)<BigInt(q.total)*UNIT)fail('Custody tokens are temporarily unavailable.',503);
    return signedTransaction([...transferTo(studioAddress,BigInt(q.studioFee)*UNIT),...transferTo(revenueAddress,BigInt(q.base)*UNIT/10n),spl.createBurnCheckedInstruction(treasuryAta,key(mint),treasury.publicKey,BigInt(q.base)*UNIT/10n,6),memo('shinobi-purchase-v2:'+id)]);
   });await progress(row,'purchase');const data=await state(wallet);return {purchase:publicOperation(data.purchases.find(r=>r.request_id===id)||row,'purchase'),...data};
  }
  if(action==='ack-purchase')return store.acknowledgePurchase(wallet,requestId(body.requestId));
  if(action==='withdraw'){
   await checkMint();const n=amount(body.amount),id=requestId(body.requestId);if(n<economy.MIN_WITHDRAW)fail('Withdrawal minimum is 100,000 Ryo.');
   const row=await store.reserve(wallet,id,n,async()=>{const available=await connection.getTokenAccountBalance(treasuryAta,'finalized');if(BigInt(available.value.amount)<BigInt(n)*UNIT)fail('Treasury tokens are temporarily unavailable. Contact the organizer.',503);const studioFee=economy.fee(n),net=n-studioFee,tx=await signedTransaction([...transferTo(wallet,BigInt(net)*UNIT),...transferTo(studioAddress,BigInt(studioFee)*UNIT),memo('shinobi-withdraw-v2:'+id)]);return {...tx,studioFee,net}});
   await progress(row);const data=await state(wallet);return {withdrawal:publicOperation(data.withdrawals.find(r=>r.request_id===id)||row),...data};
  }
  fail('Unknown Ryo API action.',404);
 }
 return {handle,progress,checkNetwork};
}
module.exports={createService,verifyDeposit,verifySignature,amount,requestId,GENESIS};
