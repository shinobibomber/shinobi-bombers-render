# Solana Ryo — Deposit and Withdrawal Beta

Use Shinobi-Bombers-Solana-Economy-V2.zip for this version. It contains a Netlify Functions project and public game files. Deposits and withdrawals require the backend, database and treasury described below. Uploading the old static ZIP with Netlify Drop does not deploy this backend.

## Economy v2 — confirmed rules

Minimum withdrawal: 100,000 Ryo gross; one finalized successful withdrawal per rolling 24 hours, enforced by the server. Maximum remains 1,000,000 gross per request. A 2% studio fee is deducted from deposits/withdrawals: 100,000 gross deposits credit 98,000 Ryo; 100,000 gross withdrawals pay 98,000 tokens.

Every gameplay purchase now uses deposited tokens directly, with a 2% studio surcharge. Of the base price, 10% transfers to treasury revenue, 10% is burned on-chain and 80% stays as operations reserve. A single summon costs 25,500 total (25,000 base + 500 fee). Fusion also costs 25,000 base per output. Existing training/Dojo/Sensei base prices remain.

The prepaid game-pack flow has been retired. Demo/gameplay rewards cannot pay token products or be withdrawn. Purchased heroes, training levels and service ownership are server records; heroes are game entitlements, not NFTs. See ECONOMY-V2.md for examples, migration and recovery details. The old video demonstrates v1, not these new fees/rules.

This remains a custodial Solana Devnet beta. No public deployment is performed by the package.

## 1. Create or reuse your Devnet mint

Follow the token setup page at /deploy.html using Phantom or Solflare. You may reuse the previous version's fixed-supply, six-decimal SPL mint. Download beta-config.json after creation. Your wallet must approve the public creation transaction; the ZIP itself does not create a mint.

For a newly created mint, the fixed 1-billion supply splits 980 million to the issuer and 20 million to the configured studio address. Existing compatible mints remain reusable without a retroactive initial fee. Use that page to send test tokens to player accounts. Keep that organizer wallet separate from the treasury and player wallets.

## 2. Create a PostgreSQL database

Create an empty PostgreSQL database with a managed provider of your choice, for example Neon or Supabase. Copy its TLS-enabled connection URI into your private environment file as DATABASE_URL. A pooled URI suitable for serverless connections is recommended. Keep the schema and its backups; deleting the ledger loses account balances and transaction recovery records.

Use a dedicated database/user for this beta. Do not put the connection URI in beta-config.json, frontend JavaScript, the public directory, or chat.

## 3. Prepare the private treasury and environment file

1. Extract the new ZIP into a local project folder. Install Node.js 22 or newer.
2. Open a terminal in that folder and run:

```text
npm install --no-audit --no-fund
npm run treasury:create
```

The helper creates .env.ryo-private in that project root and prints only the treasury's public address. It refuses to overwrite an existing file. The private key is generated on your computer and saved only in that private file. Do not upload it to public/, commit it, paste it in chat, or share it with testers.

3. Send free Devnet SOL to the printed treasury address using the official Solana faucet. It needs SOL for withdrawals and recipient-account rent. Player deposits supply its token balance; no token reserve is needed for unspent deposits if the treasury is left intact.
4. Add these entries to .env.ryo-private in a text editor, retaining the generated RYO_TREASURY_SECRET entry:

```text
DATABASE_URL=YOUR_PRIVATE_POSTGRES_CONNECTION_URI
RYO_TREASURY_SECRET=GENERATED_64_BYTE_JSON_ARRAY_ALREADY_IN_THIS_FILE
RYO_TOKEN_MINT=YOUR_DEVNET_SPL_MINT_ADDRESS
RYO_SITE_ORIGIN=https://YOUR-SITE.netlify.app
SOLANA_DEVNET_RPC_URL=https://api.devnet.solana.com
RYO_STUDIO_WALLET=YOUR_STUDIO_PUBLIC_SOLANA_ADDRESS
RYO_REVENUE_WALLET=YOUR_TREASURY_REVENUE_PUBLIC_SOLANA_ADDRESS
```

The RYO_SITE_ORIGIN is the exact HTTPS origin, without a path. Use your actual mint address, not an Ethereum address. The server verifies the RPC genesis hash against Devnet before token operations. For a larger beta, use a reliable HTTPS Devnet RPC provider. This server RPC URL can contain a private provider key because it stays in Functions environment settings.

Never substitute a mainnet wallet or mint. Do not manually drain treasury tokens that back player deposits.

5. Initialize the schema once:

```text
npm run db:init
```

This creates the accounts, authentication challenges/sessions, deposit records, game-pack spends and recoverable withdrawals. The script is safe to run again to create any missing tables. It does not erase existing balances.

## 4. Configure and deploy Netlify Functions

1. Use your existing Netlify site to preserve game saves. If you need a new site URL first, publish the public folder once, then copy its HTTPS origin into the private environment file.
2. From the extracted project root, log in and link that site:

```text
npx netlify-cli login
npx netlify-cli link
```

3. In the Netlify dashboard, set the seven private environment values from the file for the Functions runtime, production context. Alternatively import them from the private file without putting secrets in command arguments:

```text
npx netlify-cli env:import .env.ryo-private
```

Do not expose these variables to frontend build code. Netlify requires a new deploy after environment changes. Do not set secrets in netlify.toml.

4. Replace public/beta-config.json with the downloaded mint configuration. The client and server mint must match. The public rpcUrl may use the public Devnet endpoint or a browser-safe RPC URL; a browser RPC credential is public, unlike the server-only SOLANA_DEVNET_RPC_URL.
5. Deploy from the project root:

```text
npm run deploy
```

The command deploys public/ and netlify/functions. The root netlify.toml selects the same directories. The server and secret file are outside public/. Use the CLI or Git deployment; Netlify Drop of public/ alone will not deploy the withdrawal service.

6. In the dashboard, verify that the ryo function exists. If signing in reports the service is unavailable, check the environment names, database schema, TLS database access, token mint and treasury Devnet SOL. The API hides private database/key errors rather than returning secrets.

## 5. Tester flow

1. Give the player tBRYO using the issuer distribution tool (2% studio fee), and obtain Devnet SOL for deposit gas.
2. Open Ryo wallet, connect Phantom/Solflare and sign in. The server creates two starter game heroes.
3. Deposit 200,000 gross. The wallet transfers 196,000 to custody and 4,000 to studio; deposited balance becomes 196,000.
4. Open Summoning Shrine. Review a one-hero checkout: 25,000 base + 500 studio = 25,500 total. It transfers 2,500 treasury revenue, burns 2,500 and retains 20,000 operations reserve.
5. Pay and wait for finalization, then reveal the hero card. Deposited balance is now 170,500. Training, fusion, Dojo and Sensei use the same quoted checkout flow.
6. Withdraw 100,000 gross. It pays 98,000 to the player and 2,000 studio; 70,500 deposited Ryo remains. The next withdrawal is blocked for 24 hours after finalized success.
7. Deposit again if needed; it does not reset or bypass the cooldown. Check the next available timestamp in the wallet and Refresh after eligibility.
8. Verify demo-button/gameplay rewards change only practice funds, not deposited tokens or purchase eligibility.

Studio, revenue and custody addresses must be separate from player addresses. Studio and revenue can share one public destination, but neither may be the custody wallet.

## Recovery and accounting rules

- Deposit recovery: pending signatures are recorded before broadcast. Reconnect the same account and sign in, then Refresh. The server credits each finalized deposit signature once, across browsers and sessions. A failed or unfinished transaction cannot credit Ryo.
- Withdrawal recovery: the database reserves funds and stores the signed payout before broadcasting. Refresh resubmits that exact transaction when appropriate; it never signs a second payout for the same request ID.
- Slow payout: reserved funds remain unavailable until finalized success, finalized failure, or verified expiry without an observed transaction. A merely confirmed/unfinalized payout is never refunded automatically.
- Failed/expired payout: the reservation is refunded exactly once. A new withdrawal request may then be made.
- Lost HTTP response: retry the same withdrawal amount to reuse the browser's saved request ID, or Refresh to inspect its status. The server accepts at most one pending withdrawal per wallet. Avoid repeatedly clicking new requests.
- Purchase recovery: finalized orders restore their heroes/levels/services from the server. Failed or expired settlements refund the full reserved price and do not deliver an asset. Studio transfers, revenue transfers and burn execute atomically.
- This beta has no background settlement worker. Recovery is driven by the player's Refresh action or another authenticated state request. Back up the PostgreSQL database and preserve the treasury key across redeploys.
- Changing the mint or treasury uses a different ledger scope. Keep both stable while players have balances. There is no automatic migration or payout from the old scope.

## Validation and deployment status

Automated checks cover PostgreSQL schema/transactions using a local PostgreSQL engine, Ed25519 authentication, nonce replay, deposit verification, idempotent credits, server debits, signed treasury payouts, ambiguous broadcasts, exact-transaction retries, withdrawal expiry/refunds, and isolation from browser/demo Ryo. Wallet RPCs are simulated for transaction tests; no public payout or validator execution is implied.

Database provisioning, Netlify environment settings, Devnet mint creation and treasury funding must be completed in your accounts. The generated ZIP contains no treasury private key, database credentials, developer saves, or deployed-service credentials. Real wallet approval and a small end-to-end Devnet test remain required after configuration.

## Official references

- [Solana token transfers](https://solana.com/docs/tokens/basics/transfer-tokens)
- [Solana faucet](https://faucet.solana.com/)
- [Netlify Functions deployment](https://docs.netlify.com/api-and-cli-guides/cli-guides/manage-functions/)
- [Netlify Functions environment variables](https://docs.netlify.com/build/functions/environment-variables/)
- [PostgreSQL client transactions](https://node-postgres.com/features/transactions)


