# Shinobi Bombers — Solana Wallet Beta

This version uses Solana Devnet, Phantom or Solflare, and the standard SPL Token program. tBRYO is the in-game label for your beta token. The mint has six decimals and an initial fixed supply of 1,000,000,000 tokens. Test tokens have no monetary value.

No public mint has been created by generating this package. You create it by approving the setup transaction in your wallet. Player wallet keys and recovery phrases are never collected. The deposit/withdrawal upgrade uses a separate private treasury signer in server-only environment settings; see RYO-SETUP.md.

## 1. Set up your wallet

1. Install [Phantom](https://phantom.com/download) or [Solflare](https://solflare.com/download) from its official site. Use a beta testing account.
2. Phantom: Settings → Developer Settings → Testnet Mode → Solana Devnet. For Solflare, select Devnet in its network settings.
3. Copy your Solana public address. This is a base58 address, not an Ethereum 0x address.
4. Get free Devnet SOL at the [official Solana faucet](https://faucet.solana.com/). Choose Devnet, paste your public address, and follow the faucet instructions. Availability and limits vary.
5. You need SOL for transaction fees and account rent. tBRYO cannot pay these costs. Both the organizer and testers need test SOL.

The app constructs, checks, signs and submits Solana transactions through a Devnet RPC whose genesis hash is verified. Changing a wallet's display network does not change the app's RPC. No Ethereum wallet API or Sepolia transaction is used in this release.

## 2. Deploy the economy v2 package

Use Shinobi-Bombers-Solana-Economy-V2.zip and follow RYO-SETUP.md. This is a Netlify Functions project with public/, server/ and netlify/functions/ directories, not a static-only upload. Configure the database, custody signer, studio and revenue public addresses, run db:init, and deploy public files and Functions together.

For initial token creation before server setup, you may temporarily publish only public/ to obtain an HTTPS URL. That static preview cannot run token purchases, deposits or withdrawals.

## 3. Create tBRYO on Devnet

1. On deploy.html, connect Phantom or Solflare. Confirm the intended Solana account and Devnet SOL balance.
2. Enter the studio public Solana address, matching RYO_STUDIO_WALLET. Click Create tBRYO on Devnet, review the wallet transaction, and approve.
3. One atomic transaction creates the SPL mint and your associated token account, mints 1 billion total tokens split 980 million issuer / 20 million studio, and revokes mint authority. Freeze authority is disabled from initialization. No wallet can mint more or freeze accounts after creation.
4. Wait for finalization. The page displays your mint address and a Solana Explorer link with cluster=devnet.
5. If confirmation is interrupted, reconnect the original account and use Recover pending transaction. Do not create another mint just because the first confirmation is slow. Pending records contain public transaction details only.

The temporary mint-account signer exists only in browser memory, is used to create its account, and is never stored or downloaded. It does not control the token supply after mint authority is revoked. Your connected wallet holds the tokens.

This version uses the existing SPL Token program; no custom Solana program needs deployment. Name, symbol and logo metadata are not created on-chain. Wallets may display an unnamed token; identify it by the mint address. Metadata can be added as a separate future feature.

## 4. Publish the mint configuration

1. Click Download beta-config.json after mint creation.
2. Replace beta-config.json in your extracted upload folder with the downloaded file.
3. Redeploy the complete folder to the same Netlify site.
4. Refresh the game in a different browser/profile and check that its wallet panel shows your mint address.

The public file has this structure. Use the downloaded file with your actual address:

```json
{
  "network": "solana-devnet",
  "rpcUrl": "https://api.devnet.solana.com",
  "tokenAddress": "YOUR_SOLANA_MINT_ADDRESS"
}
```

The deployment browser can use its locally saved mint immediately. Other testers need the published configuration. Solana and Ethereum settings and pending transactions use separate storage namespaces; the previous Ethereum token is not migrated or bridged. Normal game saves stay unchanged on the same site URL.

## 5. Give testers tokens

1. Ask testers for their Solana public addresses only.
2. On deploy.html, connect the wallet holding the initial supply.
3. Paste a tester address under Send tokens to testers.
4. Click Send 1,000,000 tBRYO gross and approve: 980,000 goes to the tester and 20,000 to the studio. The transaction creates the recipient's associated token account if needed, then transfers tokens from your balance. You pay its Devnet rent and fee.
5. Repeat for other testers. The button is disabled if your balance is insufficient.

This replaces the earlier Ethereum contract's self-service faucet with organizer distribution. A standard fixed-supply SPL mint has no per-wallet claim cooldown logic. There is no public token faucet or hidden mint-authority key in the website. Application flows charge the configured 2% studio fee; standard transfers outside this app are not taxed.

## 6. Deposit and withdrawal upgrade

The current Ryo wallet uses server-backed deposits and withdrawals. Read RYO-SETUP.md or open /RYO-SETUP.html for the required PostgreSQL database, Netlify Functions and private treasury configuration. Use Shinobi-Bombers-Solana-Economy-V2.zip and ECONOMY-V2.md. The static folder alone does not provide that server.

1 token equals 1 deposited Ryo. Players can withdraw unspent deposits (100k minimum gross, one success every 24h, 2% fee) or pay through token checkout for each purchase. Game earnings and demo-button funds are non-withdrawable. The previous token-burn redemption has been replaced in the wallet interface.

## 7. Limits and troubleshooting

- Game Ryo and saves remain browser-local. Deposited Ryo is recorded in the server ledger described in RYO-SETUP.md; gameplay earnings cannot be withdrawn. The Market remains a local prototype.
- Public RPC limits: the default public Devnet endpoint can throttle or block browser traffic. For a larger beta, replace rpcUrl in beta-config.json with an HTTPS Devnet endpoint that permits your site's browser origin. It must return the correct Devnet genesis hash. Any credential in a browser RPC URL is public; use origin restrictions and never put a private server API secret there.
- Wrong RPC network: transactions are blocked when the genesis hash is not Devnet. Do not replace it with a mainnet endpoint.
- No wallet found: use its extension or mobile app browser. Wallet approval on actual devices still needs testing.
- Token not configured: create it, download the JSON, and redeploy the full folder.
- Token verification failed: check your mint, Devnet RPC, six decimals, original SPL program, supply cap, and revoked mint/freeze authorities.
- Pending record with no transaction: a signed transaction can expire or fail submission before reaching the chain. Check its Explorer link. Only retry after verifying it was not finalized; incomplete records never credit Ryo. Refresh does not re-submit signed transactions.
- Devnet can reset and has no production uptime guarantee. This package is for beta testing.

## 8. Developer rebuild and validation

```text
cd blockchain
npm ci --no-audit --no-fund
npm run build:solana
npm run test:solana
cd ..
node tools/update-manifest.cjs
node tools/build-standalone.cjs
node tools/build-netlify-demo.cjs
```

Pinned SDK versions: @solana/web3.js 1.98.4 and @solana/spl-token 0.4.14. Browser dependencies are bundled locally. The old Solidity source/tests are retained as historical development files and are excluded from the Solana upload package; they are not used by this release.

Validation uses actual Solana transaction serialization/signature verification and mocked Devnet RPC and wallet providers, plus browser smoke tests. Public mint creation and real wallet approval remain pending your signature. No validator-backed/public transaction success is implied by the automated tests.

## Official references

- [Solana Devnet and RPC limits](https://solana.com/docs/references/clusters)
- [Create a Solana token mint](https://solana.com/docs/tokens/basics/create-mint)
- [Burn SPL tokens](https://solana.com/docs/tokens/basics/burn-tokens)
- [SPL Token basics](https://solana.com/docs/tokens/basics)
- [Phantom Solana transaction signing](https://docs.phantom.com/solana/sending-a-transaction)
- [Phantom testnet mode](https://help.phantom.com/articles/use-testnets-in-phantom-5997313271699)
- [Netlify manual deploy instructions](https://docs.netlify.com/deploy/create-deploys/)


