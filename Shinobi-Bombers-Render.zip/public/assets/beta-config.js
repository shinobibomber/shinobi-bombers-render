/* Public Solana Devnet settings only. Publish beta-config.json after creating the mint. */
window.ShinobiBetaConfig={network:'solana-devnet',rpcUrl:'https://api.devnet.solana.com',tokenAddress:null};
