/* Solana Devnet SPL beta. Signing stays in Phantom/Solflare; no private keys are persisted. */
(() => {
 'use strict';
 const sdk=window.ShinobiSolana,NETWORK='solana-devnet',GENESIS='EtWTRABZaYq6iMfeYKouRu166VU2xqa1wcaWoxPkrZBG',DECIMALS=6,UNIT=1000000n,SUPPLY=1000000000n*UNIT;
 const pendingKey='shinobi-solana-pending-v1',configKey='shinobi-solana-token-v1',MEMO=new sdk.PublicKey('MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr');
 async function rpcFetch(input,options={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
  try{const response=await fetch(input,{...options,signal:controller.signal});if(response.status===429)throw Error('Solana Devnet is rate-limiting requests. Pending transactions are preserved; wait briefly and Refresh.');const body=await response.text();return new Response(body,{status:response.status,statusText:response.statusText,headers:response.headers})}
  catch(e){if(controller.signal.aborted)throw Error('Solana Devnet request timed out. Pending transactions are preserved. Refresh to retry; do not submit another payment.');throw e}
  finally{clearTimeout(timer)}
 }
 const makeConnection=url=>new sdk.Connection(url,{commitment:'confirmed',disableRetryOnRateLimit:true,fetch:rpcFetch});
 let rpcUrl='https://api.devnet.solana.com',connection=makeConnection(rpcUrl),provider=null,listeners=null;
 const state={account:null,wallet:null,network:NETWORK,tokenAddress:null,studioAddress:null,verified:false,tokenBalance:'0',solBalance:0,busy:false,message:'Connect Phantom or Solflare to try Solana Devnet.',txHash:null};
 const key=value=>new sdk.PublicKey(value),valid=value=>{try{return key(value).toBase58()===value}catch{return false}};
 const format=raw=>{const n=BigInt(raw||0),frac=(n%UNIT).toString().padStart(6,'0').replace(/0+$/,'');return (n/UNIT).toLocaleString()+(frac?'.'+frac:'')};
 function notify(message){if(message!==undefined)state.message=message;dispatchEvent(new CustomEvent('shinobi-beta-wallet',{detail:{...state}}))}
 function readPending(){try{const data=JSON.parse(localStorage.getItem(pendingKey)||'[]');return Array.isArray(data)?data:[]}catch{return []}}
 function acknowledge(hash){localStorage.setItem(pendingKey,JSON.stringify(readPending().filter(r=>r.hash!==hash)))}
 function store(record){localStorage.setItem(pendingKey,JSON.stringify([...readPending().filter(r=>r.hash!==record.hash),record]))}
 function base58(bytes){let n=0n;for(const b of bytes)n=n*256n+BigInt(b);let out='';const alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';while(n){out=alphabet[Number(n%58n)]+out;n/=58n}for(const b of bytes){if(b!==0)break;out='1'+out}return out}
 async function devnet(){if(await connection.getGenesisHash()!==GENESIS)throw Error('RPC is not Solana Devnet. No transaction will be sent.');}
 function reset(){state.verified=false;state.tokenBalance='0';state.solBalance=0}
 function detach(){if(provider?.removeListener&&listeners)for(const [name,fn]of Object.entries(listeners))provider.removeListener(name,fn);listeners=null}
 async function disconnect(){const previous=provider;detach();provider=null;state.account=null;state.wallet=null;reset();notify('Wallet disconnected from this page.');try{await previous?.disconnect()}catch{}}
 async function refresh(){
  reset();if(!state.account||!provider){notify();return {...state}}const account=state.account,p=provider;await devnet();
  const sol=await connection.getBalance(key(account),'confirmed');let balance='0';
  if(state.tokenAddress){await verifyMint(state.tokenAddress);const ata=sdk.getAssociatedTokenAddressSync(key(state.tokenAddress),key(account));const info=await connection.getAccountInfo(ata,'confirmed');if(info)balance=(await connection.getTokenAccountBalance(ata,'confirmed')).value.amount;}
  if(account!==state.account||p!==provider)return {...state};state.solBalance=sol;state.tokenBalance=balance;state.verified=!!state.tokenAddress;notify('Wallet balances refreshed on Solana Devnet.');return {...state};
 }
 async function connect(kind){
  if(state.busy)throw Error('Wait for the current action.');if(!['phantom','solflare'].includes(kind))throw Error('Choose Phantom or Solflare.');
  const p=kind==='phantom'?(window.phantom?.solana||(window.solana?.isPhantom?window.solana:null)):window.solflare;
  if(!p?.connect||!p?.signTransaction)throw Error('Install '+(kind==='phantom'?'Phantom':'Solflare')+' or open this site in its mobile app browser.');
  await ready;await p.connect();const account=p.publicKey?.toBase58();if(!valid(account))throw Error('The wallet did not return a Solana address.');
  detach();provider=p;state.account=account;state.wallet=kind;reset();
  listeners={accountChanged(publicKey){state.account=publicKey?.toBase58()||null;reset();notify('Wallet account changed. Refresh to recover pending transactions.');if(state.account)refresh().catch(e=>notify(e.message))},disconnect(){state.account=null;reset();notify('Wallet connection ended.')}};
  if(p.on)for(const [name,fn]of Object.entries(listeners))p.on(name,fn);notify('Connected on the app’s Devnet RPC. Enable Devnet in your wallet to view its balances.');await refresh();return {...state};
 }
 async function context(){if(!provider||!state.account)throw Error('Connect your Solana wallet first.');const ctx={provider,account:state.account,tokenAddress:state.tokenAddress};await assertContext(ctx);return ctx}
 async function assertContext(ctx){if(provider!==ctx.provider||state.account!==ctx.account||ctx.provider.publicKey?.toBase58()!==ctx.account)throw Error('Wallet account changed. Reconnect the original account and recover pending transactions.');await devnet()}
 async function verifyMint(address){
  if(!valid(address))throw Error('A Solana token mint is not configured. Open token setup.');await devnet();
  const mint=await sdk.getMint(connection,key(address),'confirmed',sdk.TOKEN_PROGRAM_ID);
  if(!mint.isInitialized||mint.decimals!==DECIMALS||mint.mintAuthority!==null||mint.freezeAuthority!==null||mint.supply>SUPPLY)throw Error('Expected a fixed-supply, six-decimal SPL mint without mint or freeze authority.');return mint;
 }
 async function installConfig(address){await context();await verifyMint(address);state.tokenAddress=address;localStorage.setItem(configKey,JSON.stringify(config()));await refresh();notify('Solana Devnet mint configured. Download and publish beta-config.json.');return config()}
 async function run(message,fn){if(state.busy)throw Error('Another wallet action is in progress.');state.busy=true;notify(message);try{return await fn()}catch(e){notify(e.code===4001?'Wallet request cancelled.':e.message);throw e}finally{state.busy=false;notify()}}
 async function waitFor(ctx,record){
  const end=Date.now()+100000;
  while(Date.now()<end){await assertContext(ctx);const result=await connection.getParsedTransaction(record.hash,{commitment:'finalized',maxSupportedTransactionVersion:0});if(result){if(result.meta?.err){acknowledge(record.hash);throw Error('Solana transaction failed. No Ryo was added.')}return result}await new Promise(r=>setTimeout(r,2000))}
  throw Error('Finalization is pending. Use Refresh / recover pending with the same wallet; do not submit again.');
 }
 async function send(ctx,tx,kind,extra={},signers=[]){
  await assertContext(ctx);const block=await connection.getLatestBlockhash('confirmed');tx.feePayer=key(ctx.account);tx.recentBlockhash=block.blockhash;if(signers.length)tx.partialSign(...signers);
  const reviewed=Buffer.from(tx.serializeMessage()),signed=await ctx.provider.signTransaction(tx);await assertContext(ctx);
  const wire=Buffer.from(signed.serialize()),checked=sdk.validateReviewedTransaction(reviewed,wire),hash=base58(checked.transaction.signature),record={hash,kind,network:NETWORK,account:ctx.account,tokenAddress:ctx.tokenAddress,...extra};
  store(record);state.txHash=hash;notify('Submitting to Solana Devnet and waiting for finalization…');
  const sent=await connection.sendRawTransaction(wire,{skipPreflight:false,preflightCommitment:'confirmed',maxRetries:3});if(sent!==hash)throw Error('RPC returned a different transaction signature.');
  const receipt=await waitFor(ctx,record);return {record,receipt};
 }
 function verifyRedemption(receipt,record){
  if(record.network!==NETWORK||![100000,1000000].includes(record.amount)||receipt.meta?.err||!receipt.meta||receipt.transaction?.signatures?.[0]!==record.hash)throw Error('Invalid or failed redemption transaction.');
  const message=receipt.transaction.message,keys=message.accountKeys,owner=keys?.[0];
  if(!owner?.signer||owner.pubkey.toString()!==record.account)throw Error('Redemption was not signed by the expected account.');
  const ata=sdk.getAssociatedTokenAddressSync(key(record.tokenAddress),key(record.account)).toBase58(),amount=BigInt(record.amount)*UNIT,instructions=sdk.stripComputeBudgetInstructions(message.instructions,{enforcePriorityCap:false});
  if(instructions.length!==2)throw Error('Unexpected redemption instructions.');
  const burn=instructions.find(i=>i.programId.toString()===sdk.TOKEN_PROGRAM_ID.toBase58()&&i.parsed?.type==='burnChecked'),memo=instructions.find(i=>i.programId.toString()===MEMO.toBase58());const info=burn?.parsed?.info;
  if(!info||info.account!==ata||info.mint!==record.tokenAddress||info.authority!==record.account||info.tokenAmount?.amount!==amount.toString()||info.tokenAmount.decimals!==DECIMALS||memo?.parsed!=='shinobi-beta:'+record.requestId)throw Error('No matching SPL burn and redemption memo.');
  const index=keys.findIndex(k=>k.pubkey.toString()===ata),pre=receipt.meta.preTokenBalances?.find(b=>b.accountIndex===index&&b.mint===record.tokenAddress&&b.owner===record.account),post=receipt.meta.postTokenBalances?.find(b=>b.accountIndex===index&&b.mint===record.tokenAddress&&b.owner===record.account);
  if(!pre||!post||BigInt(pre.uiTokenAmount.amount)-BigInt(post.uiTokenAmount.amount)!==amount)throw Error('Token balances do not confirm the requested burn.');return record;
 }
 function setStudioAddress(value){if(!valid(value)||value===state.account)throw Error('Enter a valid studio public address separate from the connected issuer wallet.');state.studioAddress=value;notify();return value}
 async function deploy(){return run('Create 1 billion tBRYO: 98% issuer, 2% studio; mint authority is permanently revoked.',async()=>{
  const ctx=await context();setStudioAddress(state.studioAddress);const mint=sdk.Keypair.generate(),owner=key(ctx.account),ata=sdk.getAssociatedTokenAddressSync(mint.publicKey,owner),rent=await connection.getMinimumBalanceForRentExemption(sdk.MINT_SIZE),studio=key(state.studioAddress),studioAta=sdk.getAssociatedTokenAddressSync(mint.publicKey,studio),studioFee=SUPPLY/50n;
  const tx=new sdk.Transaction().add(sdk.SystemProgram.createAccount({fromPubkey:owner,newAccountPubkey:mint.publicKey,lamports:rent,space:sdk.MINT_SIZE,programId:sdk.TOKEN_PROGRAM_ID}),sdk.createInitializeMint2Instruction(mint.publicKey,DECIMALS,owner,null),sdk.createAssociatedTokenAccountIdempotentInstruction(owner,ata,owner,mint.publicKey),sdk.createAssociatedTokenAccountIdempotentInstruction(owner,studioAta,studio,mint.publicKey),sdk.createMintToCheckedInstruction(mint.publicKey,ata,owner,SUPPLY-studioFee,DECIMALS),sdk.createMintToCheckedInstruction(mint.publicKey,studioAta,owner,studioFee,DECIMALS),sdk.createSetAuthorityInstruction(mint.publicKey,owner,sdk.AuthorityType.MintTokens,null));
  const {record}=await send(ctx,tx,'deploy',{tokenAddress:mint.publicKey.toBase58()},[mint]);await installConfig(mint.publicKey.toBase58());acknowledge(record.hash);notify('Devnet mint created. Publish beta-config.json and distribute tokens to testers.');return config();
 })}
 async function distribute(recipient){if(!valid(recipient))throw Error('Enter the tester’s Solana public address.');return run('Confirm sending 1,000,000 tBRYO to this tester on Devnet.',async()=>{
  const ctx=await context();await verifyMint(ctx.tokenAddress);setStudioAddress(state.studioAddress);const mint=key(ctx.tokenAddress),owner=key(ctx.account),target=key(recipient);if(recipient===ctx.account)throw Error('Choose a different tester address.');
  const source=sdk.getAssociatedTokenAddressSync(mint,owner),destination=sdk.getAssociatedTokenAddressSync(mint,target);
  const studio=key(state.studioAddress),studioAta=sdk.getAssociatedTokenAddressSync(mint,studio);
  const tx=new sdk.Transaction().add(sdk.createAssociatedTokenAccountIdempotentInstruction(owner,destination,target,mint),sdk.createAssociatedTokenAccountIdempotentInstruction(owner,studioAta,studio,mint),sdk.createTransferCheckedInstruction(source,mint,destination,owner,980000n*UNIT,DECIMALS),sdk.createTransferCheckedInstruction(source,mint,studioAta,owner,20000n*UNIT,DECIMALS));
  const result=await send(ctx,tx,'distribution',{recipient});acknowledge(result.record.hash);await refresh();notify('980,000 tBRYO sent to tester; 20,000 studio fee.');return result;
 })}
 async function redeem(amount){if(![100000,1000000].includes(amount))throw Error('Choose a supported demo pack.');return run('Confirm burning '+amount.toLocaleString()+' tBRYO for browser-local demo Ryo.',async()=>{
  const ctx=await context();await verifyMint(ctx.tokenAddress);const requestId=Array.from(crypto.getRandomValues(new Uint8Array(16)),v=>v.toString(16).padStart(2,'0')).join(''),owner=key(ctx.account),mint=key(ctx.tokenAddress),ata=sdk.getAssociatedTokenAddressSync(mint,owner);
  const tx=new sdk.Transaction().add(sdk.createBurnCheckedInstruction(ata,mint,owner,BigInt(amount)*UNIT,DECIMALS),new sdk.TransactionInstruction({programId:MEMO,keys:[{pubkey:owner,isSigner:true,isWritable:false}],data:Buffer.from('shinobi-beta:'+requestId)}));
  const result=await send(ctx,tx,'redeem',{amount,requestId});verifyRedemption(result.receipt,result.record);await refresh();notify('SPL token burn finalized.');return result;
 })}
 async function signLogin(message){return run('Sign the Ryo account login message in your wallet. This does not move tokens.',async()=>{const ctx=await context();if(!ctx.provider.signMessage)throw Error('This wallet does not support message signing.');const result=await ctx.provider.signMessage(new TextEncoder().encode(message),'utf8');await assertContext(ctx);const bytes=result.signature||result;if(bytes.length!==64)throw Error('Invalid wallet message signature.');return btoa(String.fromCharCode(...bytes))})}
 async function deposit(amount,treasuryAddress,requestId,studioAddress){
  if(!Number.isSafeInteger(amount)||amount<1000||amount>1000000||!valid(treasuryAddress)||!valid(studioAddress)||treasuryAddress===studioAddress||!/^[-a-zA-Z0-9_]{16,80}$/.test(requestId||''))throw Error('Choose 1,000–1,000,000 whole Ryo and configured custody/studio destinations.');
  const studioFee=Math.ceil(amount/50),net=amount-studioFee;
  return run('Deposit '+amount.toLocaleString()+' tokens: '+studioFee.toLocaleString()+' studio fee, '+net.toLocaleString()+' deposited Ryo.',async()=>{
   const ctx=await context();await verifyMint(ctx.tokenAddress);if(ctx.account===treasuryAddress)throw Error('Use a player wallet, separate from the treasury.');const owner=key(ctx.account),mint=key(ctx.tokenAddress),treasury=key(treasuryAddress),source=sdk.getAssociatedTokenAddressSync(mint,owner),destination=sdk.getAssociatedTokenAddressSync(mint,treasury);
   const studio=key(studioAddress),studioAta=sdk.getAssociatedTokenAddressSync(mint,studio);
   const tx=new sdk.Transaction().add(sdk.createAssociatedTokenAccountIdempotentInstruction(owner,destination,treasury,mint),sdk.createAssociatedTokenAccountIdempotentInstruction(owner,studioAta,studio,mint),sdk.createTransferCheckedInstruction(source,mint,destination,owner,BigInt(net)*UNIT,DECIMALS),sdk.createTransferCheckedInstruction(source,mint,studioAta,owner,BigInt(studioFee)*UNIT,DECIMALS),new sdk.TransactionInstruction({programId:MEMO,keys:[{pubkey:owner,isSigner:true,isWritable:false}],data:Buffer.from('shinobi-deposit-v2:'+requestId)}));
   return send(ctx,tx,'deposit',{economyVersion:2,amount,net,studioFee,requestId,treasuryAddress,studioAddress});
  });
 }
 async function recoverPending(){return run('Checking finalized Devnet transactions…',async()=>{
  if(!provider||!state.account)throw Error('Connect your Solana wallet first.');
  const records=readPending().filter(record=>record.network===NETWORK&&record.account===state.account);
  if(!records.length){await refresh();notify('Wallet refreshed. No pending Devnet transactions.');return []}
  const ctx=await context(),redeemed=[];let unresolved=0,failed=0;
  for(const record of records){
  await assertContext(ctx);const receipt=await connection.getParsedTransaction(record.hash,{commitment:'finalized',maxSupportedTransactionVersion:0});if(!receipt){unresolved++;continue}if(receipt.meta?.err){acknowledge(record.hash);failed++;continue}
  if(record.kind==='deploy'){await installConfig(record.tokenAddress);acknowledge(record.hash)}else if(record.kind==='deposit'&&record.tokenAddress===state.tokenAddress){await verifyMint(record.tokenAddress);redeemed.push({record,receipt})}else if(record.kind==='redeem'&&record.tokenAddress===state.tokenAddress){await verifyMint(record.tokenAddress);verifyRedemption(receipt,record);redeemed.push({record,receipt})}else if(record.kind==='distribution')acknowledge(record.hash);
 }await refresh();notify(unresolved?'Recovery check complete. '+unresolved+' transaction(s) are not finalized yet; their records are preserved. Refresh later.':redeemed.length?'Recovery check complete. '+redeemed.length+' finalized transaction(s) found.':failed?'Recovery check complete. Failed transaction(s) were removed; no Ryo was credited.':'Recovery check complete. No pending Devnet transactions.');return redeemed})}
 function config(){return {network:NETWORK,rpcUrl,tokenAddress:state.tokenAddress,studioAddress:state.studioAddress}}
 const ready=(async()=>{let cfg=window.ShinobiBetaConfig||{};try{const saved=JSON.parse(localStorage.getItem(configKey)||'null');if(saved?.network===NETWORK)cfg=saved}catch{}
  if(/^https?:$/.test(location.protocol))try{const response=await fetch(new URL('beta-config.json',location.href),{cache:'no-store'});if(response.ok){const published=await response.json();if(published.network!==NETWORK)throw Error('Publish the Solana Devnet configuration from this package.');cfg=published.tokenAddress?published:{...cfg,rpcUrl:published.rpcUrl||cfg.rpcUrl}}}catch(e){notify('Configuration: '+e.message)}
  if(cfg.network===NETWORK){if(cfg.rpcUrl){const url=new URL(cfg.rpcUrl);if(url.protocol!=='https:')throw Error('Devnet RPC must use HTTPS.');rpcUrl=url.href;connection=makeConnection(rpcUrl)}if(valid(cfg.tokenAddress))state.tokenAddress=cfg.tokenAddress;if(valid(cfg.studioAddress))state.studioAddress=cfg.studioAddress}notify();return {...state};})();
 window.BetaWallet={ready,connect,disconnect,refresh,deploy,distribute,deposit,signLogin,setStudioAddress,redeem,installConfig,recoverPending,verifyRedemption,acknowledge,format,config,get state(){return {...state}},setMessage:notify,explorerTx:hash=>/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(hash||'')?'https://explorer.solana.com/tx/'+hash+'?cluster=devnet':null};
})();
