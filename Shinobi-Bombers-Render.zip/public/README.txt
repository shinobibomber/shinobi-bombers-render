SHINOBI BOMBERS — NETLIFY TESTER DEMO

UPLOAD
1. Extract the supplied Shinobi Bombers demo ZIP into a folder.
2. Confirm index.html is directly inside that folder.
3. Sign in to Netlify, open https://app.netlify.com/drop and drag that folder into the deploy area.
4. Share the resulting netlify.app URL with your testers.

This is a prebuilt static demo: no build command, Node installation, API keys or source folder is required.
Netlify manual deploy guide: https://docs.netlify.com/deploy/create-deploys/

TESTER NOTES
- The temporary +100,000 demo funding button has been removed.
- Each browser keeps its own local progress. No developer/test save is included.
- Milestones includes save export/import for backing up or transferring a test save.
- The Market is a local listing prototype; shared trading and accounts are not implemented.
- Game code, styles and character art are embedded in index.html. The optional web font falls back if unavailable.

UPDATES
Upload a newly generated folder to the existing Netlify project's deploy area to update the same URL.
Keep the same site URL so browser-local tester saves remain available.

SOLANA WALLET BETA
For deposits/withdrawals use Shinobi-Bombers-Solana-Economy-V2.zip. See SETUP.html or BETA-SETUP.md for Phantom/Solflare setup, Devnet SOL, mint creation, organizer distribution and Ryo deposit/withdrawal setup. Create the fixed-supply SPL token at /deploy.html using your wallet, then download beta-config.json and publish it in this folder. No public mint has been created by this build step.

DEPOSIT/WITHDRAW UPGRADE
Use Shinobi-Bombers-Solana-Economy-V2.zip and RYO-SETUP.md for the Functions-backed wallet. This static folder alone cannot run deposits/withdrawals.
