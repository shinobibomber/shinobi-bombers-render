# Solana Ryo economy v2

This implements the user's confirmed policy on Solana Devnet. The server is authoritative for deposited balances, catalog prices, owned paid heroes, training levels, Dojo tiers and Sensei ownership. No public service has been deployed by this build.

## Withdrawal rule

The minimum is **100,000 Ryo gross per request**. The existing beta maximum remains 1,000,000 gross per request. Only one successful withdrawal is allowed per wallet per rolling 24 hours. The window starts when the server records finalized success. It is not a calendar-day reset and cannot be bypassed by changing browser time.

The 2% studio fee is deducted from the gross withdrawal. For example, requesting 100,000 debits 100,000 deposited Ryo, pays 98,000 tokens to the player and 2,000 tokens to the studio. A refunded/expired/failed withdrawal does not start the cooldown. An observed unfinalized withdrawal stays reserved. Repeating its request ID recovers it without charging twice.

## Fees and allocation

| Action | Charge and outcome |
| --- | --- |
| Deposit 100,000 tokens | 98,000 deposited Ryo; 2,000 tokens transferred to studio |
| Withdraw 100,000 Ryo | 98,000 tokens to player; 2,000 tokens transferred to studio |
| Summon one hero | 25,000 base + 500 studio = 25,500 deposited Ryo charged |
| Base allocation for that summon | 2,500 treasury revenue; 2,500 permanently burned; 20,000 operations reserve |
| Fusion output | 25,000 base + 500 studio; three owned same-rank heroes consumed |
| Initial SPL token creation | Fixed 1-billion total supply: 980 million issuer, 20 million studio |
| Organizer distributes 1 million gross | 980,000 to tester and 20,000 studio fee |

The 20% purchase allocation is **10% treasury + 10% burn**, not 20% burn plus another treasury fee. The studio fee is an additional 2% of the base purchase price. Studio fees round up to a whole Ryo; the 10% token allocations use exact six-decimal SPL units. Solana network fees/account rent are separate and do not go to the studio.

These fees apply to the application's supported monetary flows. This uses the original SPL Token program, so ordinary wallet-to-wallet transfers outside the app do not automatically charge a studio fee. A global token transfer tax would require a different token/program design.

Deposits and organizer distributions transfer their gross total split between the recipient/custody and studio, in one wallet-signed transaction. Withdrawals transfer the gross split between player and studio in one treasury-signed transaction. Purchases transfer the studio fee and 10% treasury revenue and execute BurnChecked for 10% of base in a single atomic transaction. The remaining 80% of base stays in the custody wallet as non-player operations reserve. Unspent player deposits stay fully backed; they are not used to subsidize burns for unpaid purchases.

## Paid catalog

- Summons: 25,000 base each; quantities 1, 5, 10 or 15. Rarity odds remain 60/25/10/4/1, generated on the server after order acceptance.
- Fusion: 25,000 base per output; three unique owned same-rank heroes below Legend. Batch limit 25 outputs. Inputs are consumed only after finalized payment.
- Training: existing level/rarity formula, calculated from the server's hero record. Maximum level 10.
- Dojo: existing sequential tier prices 1.8m, 6m, 13.5m, 24m, 37.5m and 54m base.
- Sensei: 1,512,500 base; one permanent hire.
- Two starter heroes are granted once per wallet profile. They are game starter grants, not an SPL mint or an NFT mint.
- Prison/other local practice heroes and imported collections cannot be submitted as paid fusion/training inputs without a server ownership record. Their gameplay continues as practice content.
- The Market is still an offline listing prototype. It does not accept purchases or pretend to settle token trades.

Every active purchase entry point uses token checkout. The previous prepaid game-pack endpoint is disabled. The main Ryo balance shows deposited tokens; local gameplay earnings and demo-button rewards remain visible in the wallet as practice rewards, and cannot buy token products or be withdrawn. Legacy practice progress is not converted into deposited tokens.

Purchased heroes are **server game entitlements**, not wallet NFTs. Their payment and supply burn occur on-chain; this update does not create NFT metadata, collectible mint accounts or a shared trading market. The initial fungible token's mint authority is permanently revoked, so gameplay purchases do not mint more tBRYO.

## Settlement and recovery

The database reserves the full price before broadcast and saves the exact signed transaction. A paid hero, level, service or fusion output is delivered only on finalized success. All fee transfers and the burn are atomic: if any fails, the complete purchase fails. Finalized failure or verified unobserved expiry refunds the full reserved amount once and leaves the ownership profile unchanged.

Only one token purchase can be pending per wallet. Quotes are revalidated under the same database account lock as the debit. Old request IDs cannot reroll summons or apply an upgrade twice. Refresh recovers pending orders and restores the paid collection from the server. The game presentation remains a browser beta; editing local save files cannot increase the server balance or buy server entitlements.

## Operator upgrade checklist

1. Back up PostgreSQL and the private custody key. Finish old-version pending deposits/withdrawals before upgrading clients; the new client requires fee-bearing v2 deposit transactions.
2. Keep mint, custody and site origin stable. Existing ledger balances are preserved. Old prepaid local funds remain practice funds rather than becoming withdrawable tokens.
3. Set RYO_STUDIO_WALLET and RYO_REVENUE_WALLET in Netlify Functions environment settings. They are public Solana addresses, not private keys. They may share the same destination, but must differ from the custody wallet. Use separate player wallets.
4. Run npm run db:init to apply the additive schema migration. It can safely be run twice; it does not erase balances.
5. Deploy the updated public/ and Functions together with npm run deploy. Do not deploy only static files.
6. Confirm the setup page's studio address matches RYO_STUDIO_WALLET. Existing compatible SPL mints can be reused; no retroactive initial-mint fee is collected from old supply.
7. Test a net deposit, a paid summon, on-chain studio/revenue transfers and burn, a 100k gross withdrawal, immediate second-withdrawal rejection, and the next available timestamp.

The previous video describes v1 prepaid packs and fee-free examples. Use the updated written guide for v2. Public wallet signatures, database/environment setup and a real Devnet end-to-end test are still required.

## Validation

Automated tests use a local PostgreSQL engine, real Solana SDK signatures/instruction decoding, and simulated RPC/wallet responses. They cover fee recipients/amounts, burns, catalog pricing and ownership, idempotency, exact 24-hour boundaries, failed burns, reservation refunds and UI purchase flows. This is not a validator-backed or public-chain deployment claim.

- [SPL token burns reduce supply](https://solana.com/docs/tokens/basics/burn-tokens)
- [SPL token transfers](https://solana.com/docs/tokens/basics/transfer-tokens)



## Adventure Chest update
Authenticated Adventure runs a server-owned auto-combat simulation with the strongest ten server-owned heroes. The server determines time, chakra, damage, target HP, stage progression, and rewards. Client damage, map and reward amounts are never accepted. A heartbeat runs every 15 seconds while the visible Adventure tab is active; intervals cap at 30 seconds and there are no offline reward catch-ups. Local practice maps, prison heroes and old local balances remain separate.

Chest claims credit whole Ryo to the existing spendable and withdrawable account. Fractional earnings remain in the Chest. No fee applies to this internal move; the existing 2% purchase/withdrawal fees still apply. Withdrawals retain the 100,000 minimum and rolling 24-hour rule.

The reward budget equals 80% retained operations revenue from finalized purchases minus previous Adventure claims, and is additionally capped by custody tokens less account balances and pending outgoing obligations. Player deposits are not reward revenue. Claims serialize across wallets; if funding runs out, earnings remain unclaimed. No tokens are minted. Claims are server-controlled beta rewards, not a guarantee of future earnings. Run db:init for the additive ryo_adventures/ryo_reward_pools tables before deployment.


## Adaptive enemy loot
Each defeated Adventure target's Ryo drop is multiplied by a server-calculated rate based on the funded reward pool: below 100,000 Ryo = 50%; 100,000 = 60%; 200,000 = 70%; 300,000 = 80%; 400,000 = 90%; 500,000 or more = 100%. Rates decrease again if the pool drops. Existing map-based reward tapering still applies. This adjusts newly earned enemy loot, not previously earned Chest rewards. Claims and existing withdrawal fees are unchanged. The Chest displays the current rate and next pool threshold. Client-supplied reward rates and pool values are ignored by the token reward server.
