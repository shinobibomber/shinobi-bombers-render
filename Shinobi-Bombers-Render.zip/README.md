# Shinobi Bombers — Render beta setup

This package hosts the game and wallet API together on one Render **Web Service**, using the existing Neon database. It includes the latest Chest Deposit/Withdraw popups. It does not require Netlify. No private credentials are included.

## 1. Put this clean package in a GitHub repository

Extract `Shinobi-Bombers-Render.zip`. Create a private GitHub repository and upload the contents of the extracted project folder. `package.json`, `package-lock.json`, `render.yaml`, `public/` and `server/` must be at the repository root, not inside another folder. Include the supplied `.gitignore`.

Never upload `.env.ryo-private`, a private key, a database password or `node_modules/`. Keep this repository separate from older extracted deployment folders containing secrets.

## 2. Create the service

In https://dashboard.render.com choose **New → Web Service**, connect GitHub, then select this repository. Use these settings:

| Setting | Value |
| --- | --- |
| Name | `shinobi-bombers-beta` (or another available name) |
| Language/runtime | Node |
| Branch | Your uploaded branch |
| Root Directory | Leave blank |
| Build Command | `npm ci && npm run db:init` |
| Start Command | `npm start` |
| Instance Type | Free |
| Health Check Path | `/healthz` |

Alternatively use **New → Blueprint** and select the repository; `render.yaml` supplies the service settings. Confirm the Free instance before creating it.

## 3. Add server environment variables privately

Set these in Render's **Environment** settings before the first deploy:

| Key | Value |
| --- | --- |
| `NODE_VERSION` | `22` |
| `DATABASE_URL` | Your current complete Neon pooled PostgreSQL connection URL |
| `RYO_TREASURY_SECRET` | The current custody signer's JSON secret-key array, entered privately |
| `RYO_TOKEN_MINT` | The same Devnet tBRYO mint used by the current game |
| `RYO_STUDIO_WALLET` | Your current studio public wallet address |
| `RYO_REVENUE_WALLET` | Your current revenue public wallet address |

Keep the database, token mint and custody wallet consistent with the existing beta to retain account balances, heroes, claims and withdrawal cooldowns. Studio and revenue addresses must differ from custody. Use the latest rotated credentials; keys/passwords previously exposed in screenshots or chat should not be reused.

Do **not** copy the old Netlify `RYO_SITE_ORIGIN`. On Render it is automatically derived from `RENDER_EXTERNAL_URL`. If you later use a custom domain, explicitly set `RYO_SITE_ORIGIN=https://your-custom-domain` and use that domain for wallet login. No trailing path.

Optional: `SOLANA_DEVNET_RPC_URL` for a private Devnet RPC. This remains server-side; the browser uses the public Devnet RPC.

## 4. Deploy and verify

Click **Deploy Web Service**. The build installs locked dependencies and runs the additive database initialization. It preserves existing records. Logs should end with `Shinobi Render server is listening.`

Open the assigned `https://YOUR-SERVICE.onrender.com` URL. `/healthz` should return `{"status":"ok"}`. The game should show the login screen. Sign in with a player wallet, open Chest, and verify the balance before approving any new transaction. Deposit and Withdraw open their own popups. Your existing minimum, cooldown and fees still apply.

If the old Netlify site remains active, both deployments share the same server account balances. Browser-only practice progress is stored per website origin and will not automatically move to the Render URL. A new domain requires a fresh wallet login signature; existing token-backed heroes are loaded from Neon.

## Free service behavior

Render Free sleeps after 15 minutes without inbound traffic and can take about one minute to wake. The game cannot earn offline rewards while asleep. Pending blockchain operations remain in Neon and are recovered after login. For regular investor demonstrations, consider a paid instance to avoid cold starts. Check current limits in the Render dashboard; no paid service is created by this package.

Official setup: https://render.com/docs/deploy-node-express-app

Environment variables: https://render.com/docs/configure-environment-variables

Free-tier limitations: https://render.com/docs/free
